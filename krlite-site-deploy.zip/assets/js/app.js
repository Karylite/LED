/* ==========================================================================
   KARYLITE — application logic
   Vanilla JS · hash router · i18n · inquiry list · payment flow
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.SITE_CONFIG;
  var PRODUCTS = window.KARYLITE_PRODUCTS || [];
  var LS_INQ = 'karylite_inquiry_v1';
  var LS_LANG = 'karylite_lang';

  /* ------------------------------------------------------------------ icons */
  var I = {
    arrow: '<svg class="ico-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    chev: '<svg class="ico-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M4 7l8 6 8-6"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 3h3l2 5-2.5 1.5a12 12 0 006 6L16 13l5 2v3a2 2 0 01-2.2 2A16.5 16.5 0 014 5.2A2 2 0 016 3z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-5.5 7-11a7 7 0 10-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>',
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 12a8 8 0 01-11.6 7.1L4 21l1.9-5.3A8 8 0 1121 12z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3l7.5 3v6c0 4.6-3 8.3-7.5 9.7C7.5 20.3 4.5 16.6 4.5 12V6L12 3z"/><path d="M9.2 12.2l2 2 3.6-4"/></svg>',
    zap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12L13 2z"/></svg>',
    layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/><path d="M3 17l9 5 9-5"/></svg>',
    box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M3.5 7.5L12 3l8.5 4.5v9L12 21l-8.5-4.5v-9z"/><path d="M3.5 7.5L12 12l8.5-4.5M12 21V12"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8"/></svg>',
    drop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3s6 6.4 6 10.6A6 6 0 016 13.6C6 9.4 12 3 12 3z"/></svg>',
    ruler: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M3 16.5L16.5 3 21 7.5 7.5 21 3 16.5z"/><path d="M8 12l2 2M11 9l2 2M14 6l2 2"/></svg>',
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>',
    truck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M2.5 6.5h10v9h-10z"/><path d="M12.5 9.5H17l3 3v3h-7.5"/><circle cx="6" cy="17.5" r="1.8"/><circle cx="16.5" cy="17.5" r="1.8"/></svg>',
    award: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><circle cx="12" cy="9" r="5.5"/><path d="M8.5 13.8L7 21l5-2.6L17 21l-1.5-7.2"/></svg>',
    doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/></svg>',
    card: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M6 15h3"/></svg>',
    bank: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M3 10l9-6 9 6"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 21h18"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="4.5" y="10" width="15" height="10.5" rx="2.5"/><path d="M8 10V7.5a4 4 0 018 0V10"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M3 4h2.2l2.3 11h10.4L20 7H6"/><circle cx="9.5" cy="19" r="1.6"/><circle cx="17" cy="19" r="1.6"/></svg>',
    up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>',
    ext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-8 8M18 14v5a1.5 1.5 0 01-1.5 1.5h-11A1.5 1.5 0 014 19V8a1.5 1.5 0 011.5-1.5H10"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 14.4c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.1-.2.3-.7 1-.9 1.2-.2.2-.4.2-.7.1a7.3 7.3 0 01-2.1-1.3 8 8 0 01-1.4-1.8c-.2-.3 0-.5.1-.6l.6-.7c.1-.2.2-.3.3-.5v-.5c-.1-.2-.7-1.7-.9-2.3-.2-.5-.4-.5-.6-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.2.2 2.1 3.3 5.1 4.6 1.9.8 2.6.9 3.5.7.6-.1 1.8-.7 2-1.5.3-.7.3-1.3.2-1.5-.1-.2-.3-.3-.6-.4z"/><path d="M12 2.5A9.5 9.5 0 003.8 16.6L2.5 21.5l5-1.3A9.5 9.5 0 1012 2.5zm0 17.2a7.7 7.7 0 01-3.9-1.1l-.3-.2-2.9.8.8-2.8-.2-.3A7.7 7.7 0 1112 19.7z"/></svg>',
    paypal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4.5h6.2c2.6 0 4 1.4 3.6 3.8-.4 2.5-2.2 3.9-4.8 3.9H11l-.8 5.3H6.6L8 4.5z"/><path d="M11.6 8.6h4.3c1.9 0 2.9 1 2.6 2.8-.3 1.9-1.6 3-3.6 3h-1.6"/></svg>',
    wise: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 8h9.2l6.3-3.6L21 8l-9.2 12L4 8z"/><path d="M3.5 8h11.9"/></svg>',
    wu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 5.5l4 13 4.5-8.5 4.5 8.5 4-13"/></svg>'
  };

  /* ------------------------------------------------------------------ state */
  var state = {
    lang: localStorage.getItem(LS_LANG) || detectLang(),
    inquiry: loadInquiry(),
    payMethod: 'bank',
    step: 1,
    filter: { cat: 'all', ip: 'all', sort: 'default', q: '' },
    mailto: ''
  };

  function detectLang() {
    var n = (navigator.language || 'en').toLowerCase().slice(0, 2);
    return window.I18N[n] ? n : 'en';
  }
  function loadInquiry() {
    try { return JSON.parse(localStorage.getItem(LS_INQ)) || []; } catch (e) { return []; }
  }
  function saveInquiry() {
    try { localStorage.setItem(LS_INQ, JSON.stringify(state.inquiry)); } catch (e) {}
    paintBadge();
  }
  function t(key, vars) {
    var d = window.I18N[state.lang] || window.I18N.en;
    var s = d[key] != null ? d[key] : (window.I18N.en[key] != null ? window.I18N.en[key] : key);
    if (vars) Object.keys(vars).forEach(function (k) { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function money(n) { return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function ref(prefix) {
    var d = new Date(), p = function (x) { return String(x).padStart(2, '0'); };
    return (prefix || 'KRL') + '-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' +
      Math.floor(1000 + Math.random() * 9000);
  }
  function prodById(id) { for (var i = 0; i < PRODUCTS.length; i++) if (PRODUCTS[i].id === id) return PRODUCTS[i]; return null; }
  function catName(c) { return t('cat_' + c); }
  function waLink(text) { return 'https://wa.me/' + CFG.whatsapp + '?text=' + encodeURIComponent(text || ''); }

  /* 公司名 / 地址：中文界面显示中文，其余语言显示英文 */
  function company() { return state.lang === 'zh' ? (CFG.companyZh || CFG.company) : CFG.company; }
  function address() { return state.lang === 'zh' ? (CFG.addressZh || CFG.address) : CFG.address; }
  function mailLink(subject, body) {
    return 'mailto:' + CFG.email + '?subject=' + encodeURIComponent(subject || '') + '&body=' + encodeURIComponent(body || '');
  }

  /* 复制纯文本：优先 Clipboard API，失败回退到临时 textarea */
  function copyText(text) {
    function done() { toast(t('copied')); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, function () { legacyCopy(text, done); });
      return;
    }
    legacyCopy(text, done);
  }
  function legacyCopy(text, done) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    } catch (err) {}
    done();
  }

  /* ---------------------------------------------------------------- toaster */
  function toast(msg, icon) {
    var wrap = document.querySelector('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
    var el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = (icon || I.check) + '<span>' + esc(msg) + '</span>';
    wrap.appendChild(el);
    setTimeout(function () { el.style.opacity = '0'; el.style.transform = 'translateY(10px)'; }, 2600);
    setTimeout(function () { el.remove(); }, 3100);
  }

  /* ------------------------------------------------------------------- modal */
  function openModal(html) {
    var m = document.getElementById('modal');
    if (!m) return;
    /* 自愈：容器结构若缺失（旧骨架/预渲染页）就地补齐，避免 openPayment 抛错 */
    if (!m.querySelector('.modal-panel')) {
      m.innerHTML = '<div class="modal-bg"></div><div class="modal-panel"></div>';
    }
    m.querySelector('.modal-panel').innerHTML = html;
    m.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeModal() {
    document.getElementById('modal').classList.remove('open');
    document.body.style.overflow = '';
  }

  /* ------------------------------------------------------------------- badge */
  function paintBadge() {
    var n = state.inquiry.reduce(function (a, b) { return a + b.qty; }, 0);
    document.querySelectorAll('[data-inquiry-count]').forEach(function (el) {
      el.textContent = n;
      el.hidden = n === 0;
    });
  }

  /* --------------------------------------------------------- inquiry helpers */
  function addToInquiry(id, qty) {
    var it = state.inquiry.filter(function (x) { return x.id === id; })[0];
    if (it) it.qty += (qty || 1); else state.inquiry.push({ id: id, qty: qty || 1 });
    saveInquiry();
    var p = prodById(id);
    toast((p ? p.model + ' — ' : '') + t('added'));
  }
  function setQty(id, q) {
    q = Math.max(1, Math.min(99999, parseInt(q, 10) || 1));
    state.inquiry.forEach(function (x) { if (x.id === id) x.qty = q; });
    saveInquiry(); render();
  }
  function removeItem(id) {
    state.inquiry = state.inquiry.filter(function (x) { return x.id !== id; });
    saveInquiry(); render();
  }

  /* --------------------------------------------------------------- i18n DOM */
  function applyStatic() {
    var meta = window.I18N.meta[state.lang] || window.I18N.meta.en;
    document.documentElement.lang = state.lang;
    document.documentElement.dir = meta.dir;
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      el.textContent = t(el.getAttribute('data-i18n'));
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(function (el) {
      el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph')));
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function (el) {
      el.innerHTML = t(el.getAttribute('data-i18n-html'));
    });
  }

  /* ================================================================ VIEWS == */
  function viewHome() {
    var featured = PRODUCTS.filter(function (p, i) { return i % 5 === 0; }).slice(0, 8);
    var cats = [
      { c: 'step', img: imgOf('step-10') }, { c: 'inground', img: imgOf('inground-42') },
      { c: 'spot', img: imgOf('spot-92') }, { c: 'underwater', img: imgOf('underwater-106') },
      { c: 'linear', img: imgOf('linear-132') }, { c: 'downlight', img: imgOf('downlight-144') }
    ];
    var apps = [
      { k: 'app_pool', img: 'assets/img/scene/app-pool.jpg' },
      { k: 'app_garden', img: 'assets/img/scene/app-garden.jpg' },
      { k: 'app_facade', img: 'assets/img/scene/app-facade.jpg' },
      { k: 'app_path', img: 'assets/img/scene/app-path.jpg' },
      { k: 'app_hotel', img: 'assets/img/scene/app-wall.jpg' },
      { k: 'app_fountain', img: 'assets/img/scene/app-fountain.jpg' }
    ];
    var whys = [
      ['layers', 'why_1', 'why_1d'], ['shield', 'why_2', 'why_2d'], ['drop', 'why_3', 'why_3d'],
      ['zap', 'why_4', 'why_4d'], ['sun', 'why_5', 'why_5d'], ['truck', 'why_6', 'why_6d']
    ];
    return '' +
      /* HERO */
      '<section class="hero">' +
      '<div class="hero-bg" id="heroBg">' +
      ['assets/img/scene/hero-1.jpg', 'assets/img/scene/hero-2.jpg', 'assets/img/scene/hero-3.jpg', 'assets/img/scene/hero-4.jpg']
        .map(function (s, i) { return '<div class="slide' + (i === 0 ? ' on' : '') + '" style="background-image:url(' + s + ')"></div>'; }).join('') +
      '</div>' +
      '<div class="wrap"><div class="hero-inner">' +
      '<span class="eyebrow">' + t('hero_eyebrow') + '</span>' +
      '<h1 class="h-display">' + t('hero_title_1') + '<br><span class="accent">' + t('hero_title_2') + '</span></h1>' +
      '<p class="lead">' + t('hero_sub') + '</p>' +
      '<div class="hero-cta">' +
      '<a class="btn btn-primary btn-lg" href="' + url('products') + '">' + t('hero_cta1') + I.arrow + '</a>' +
      '<a class="btn btn-ghost btn-lg" href="' + url('quote') + '">' + t('hero_cta2') + '</a>' +
      '</div></div></div>' +
      '<div class="hero-dots" id="heroDots">' +
      [0, 1, 2, 3].map(function (i) { return '<button data-i="' + i + '"' + (i === 0 ? ' class="on"' : '') + '></button>'; }).join('') +
      '</div></section>' +

      /* TRUST */
      '<section class="trust-strip"><div class="trust-grid">' +
      [['shield', 'trust_1', 'trust_1s'], ['award', 'trust_2', 'trust_2s'], ['truck', 'trust_3', 'trust_3s'], ['box', 'trust_4', 'trust_4s']]
        .map(function (x) {
          return '<div class="trust-item">' + I[x[0]] + '<div><b>' + t(x[1]) + '</b><span>' + t(x[2]) + '</span></div></div>';
        }).join('') +
      '</div></section>' +

      /* CATEGORIES */
      '<section class="section"><div class="wrap">' +
      '<div class="section-head center"><span class="eyebrow">' + t('cat_eyebrow') + '</span>' +
      '<h2 class="h1">' + t('cat_title') + '</h2><p class="lead">' + t('cat_sub') + '</p></div>' +
      '<div class="cat-grid">' + cats.map(function (c) {
        return '<a class="cat-card reveal" href="' + url('products') + '?cat=' + c.c + '">' +
          '<div class="cat-card-img"><img src="' + c.img + '" alt="' + esc(catName(c.c)) + '" loading="lazy"></div>' +
          '<div class="cat-card-body"><h3>' + esc(catName(c.c)) + '</h3>' +
          '<p>' + t('cat_' + c.c + '_d') + '</p>' +
          '<div class="cat-card-meta">' + t('view_all') + I.arrow + '</div></div></a>';
      }).join('') + '</div></div></section>' +

      /* FEATURED */
      '<section class="section alt"><div class="wrap">' +
      '<div class="section-head-row"><div class="section-head" style="margin-bottom:0">' +
      '<span class="eyebrow">' + t('products_eyebrow') + '</span>' +
      '<h2 class="h1">' + t('products_title') + '</h2><p class="lead">' + t('products_sub') + '</p></div>' +
      '<a class="btn btn-ghost" href="' + url('products') + '">' + t('view_all') + I.arrow + '</a></div>' +
      '<div class="prod-grid">' + featured.map(prodCard).join('') + '</div>' +
      '</div></section>' +

      /* WHY */
      '<section class="section"><div class="wrap">' +
      '<div class="section-head"><span class="eyebrow">' + t('why_eyebrow') + '</span>' +
      '<h2 class="h1">' + t('why_title') + '</h2><p class="lead">' + t('why_sub') + '</p></div>' +
      '<div class="feat-grid">' + whys.map(function (w) {
        return '<div class="feat reveal"><div class="feat-ico">' + I[w[0]] + '</div><h3>' + t(w[1]) + '</h3><p>' + t(w[2]) + '</p></div>';
      }).join('') + '</div></div></section>' +

      /* FACTORY SPLIT */
      '<section class="section alt"><div class="wrap"><div class="split">' +
      '<div><span class="eyebrow">' + t('fty_eyebrow') + '</span>' +
      '<h2 class="h1" style="margin:14px 0 14px">' + t('fty_title') + '</h2>' +
      '<p class="lead">' + t('fty_sub') + '</p>' +
      '<ul class="check-list">' +
      [['fty_1', 'fty_1d'], ['fty_2', 'fty_2d'], ['fty_3', 'fty_3d'], ['fty_4', 'fty_4d']].map(function (x) {
        return '<li>' + I.check + '<span><b>' + t(x[0]) + '</b> — ' + t(x[1]) + '</span></li>';
      }).join('') + '</ul>' +
      '<div class="stat-grid">' +
      [['stat_val_1', 'stat_1'], ['stat_val_2', 'stat_2'], ['stat_val_3', 'stat_3'], ['stat_val_4', 'stat_4']].map(function (s) {
        return '<div class="stat"><b>' + t(s[0]) + '</b><span>' + t(s[1]) + '</span></div>';
      }).join('') + '</div></div>' +
      '<div class="split-img" style="aspect-ratio:4/5"><img src="assets/img/factory/building.jpg" alt="Karylite factory — Quankai Industrial Park, Dongguan" loading="lazy"></div>' +
      '</div></div></section>' +

      /* APPLICATIONS */
      '<section class="section"><div class="wrap">' +
      '<div class="section-head"><span class="eyebrow">' + t('app_eyebrow') + '</span>' +
      '<h2 class="h1">' + t('app_title') + '</h2><p class="lead">' + t('app_sub') + '</p></div>' +
      '<div class="app-grid">' + apps.map(function (a) {
        return '<div class="app-card reveal"><img src="' + a.img + '" alt="' + esc(t(a.k)) + '" loading="lazy">' +
          '<div class="app-card-body"><h3>' + t(a.k) + '</h3><p>' + t(a.k + '_d') + '</p></div></div>';
      }).join('') + '</div></div></section>' +

      /* CTA */
      '<section class="section tight"><div class="wrap"><div class="cta-band"><div class="cta-band-inner">' +
      '<div><h2>' + t('cta_title') + '</h2><p>' + t('cta_sub') + '</p></div>' +
      '<div style="display:flex;gap:11px;flex-wrap:wrap">' +
      '<a class="btn btn-primary btn-lg" href="' + url('quote') + '">' + t('cta_btn') + I.arrow + '</a>' +
      '<a class="btn btn-ghost btn-lg" href="' + waLink('Hello Karylite, I would like a quotation for outdoor lighting.') + '" target="_blank" rel="noopener">' + I.wa + ' WhatsApp</a>' +
      '</div></div></div></div></section>';
  }

  function imgOf(id) {
    var p = prodById(id);
    return (p && p.images && p.images[0]) ? p.images[0] : 'assets/img/products/step-10-0.jpg';
  }

  function prodCard(p) {
    var inq = state.inquiry.some(function (x) { return x.id === p.id; });
    return '<article class="prod-card reveal">' +
      '<a class="prod-thumb" href="' + url('product/' + p.id) + '">' +
      '<img src="' + (p.images[0] || '') + '" alt="' + esc(p.model) + '" loading="lazy">' +
      '<div class="prod-tags"><span class="tag ip">' + esc(p.ip) + '</span><span class="tag new">2026</span></div>' +
      '</a>' +
      '<div class="prod-body">' +
      '<div class="prod-cat">' + esc(catName(p.cat)) + '</div>' +
      '<a class="prod-model" href="' + url('product/' + p.id) + '">' + esc(p.model) + '</a>' +
      '<div class="prod-specs">' +
      (p.power ? '<span>' + I.zap + esc(p.power) + '</span>' : '') +
      (p.dims ? '<span>' + I.ruler + esc(p.dims) + '</span>' : '') +
      '</div>' +
      '<div class="prod-actions">' +
      '<a class="btn btn-ghost btn-sm" href="' + url('product/' + p.id) + '">' + t('view_detail') + '</a>' +
      '<button class="btn btn-primary btn-sm" data-add="' + p.id + '">' + (inq ? t('added') : t('add_inquiry')) + '</button>' +
      '</div></div></article>';
  }

  function viewProducts() {
    var ips = [];
    PRODUCTS.forEach(function (p) { if (ips.indexOf(p.ip) < 0) ips.push(p.ip); });
    ips.sort();
    var list = filterList();
    var catList = ['all', 'step', 'inground', 'spot', 'underwater', 'linear', 'downlight'];
    return '<section class="section tight"><div class="wrap">' +
      '<div class="breadcrumb"><a href="' + url('') + '">' + t('bc_home') + '</a>' + I.chev + '<span>' + t('bc_products') + '</span></div>' +
      '<div class="section-head" style="margin-bottom:30px"><span class="eyebrow">2026 Catalogue</span>' +
      '<h1 class="h1">' + t('products_h1') + '</h1><p class="lead">' + t('products_h2') + '</p></div>' +
      '<div class="filterbar">' +
      '<div class="chips">' + catList.map(function (c) {
        return '<button class="chip' + (state.filter.cat === c ? ' on' : '') + '" data-cat="' + c + '">' +
          (c === 'all' ? t('filter_all') : esc(catName(c))) + '</button>';
      }).join('') + '</div>' +
      '<div class="filter-right">' +
      '<select class="field" data-ip>' + '<option value="all">' + t('filter_ip') + ': ' + t('filter_all') + '</option>' +
      ips.map(function (i) { return '<option value="' + i + '"' + (state.filter.ip === i ? ' selected' : '') + '>' + i + '</option>'; }).join('') + '</select>' +
      '<select class="field" data-sort>' +
      '<option value="default"' + (state.filter.sort === 'default' ? ' selected' : '') + '>' + t('sort_default') + '</option>' +
      '<option value="model"' + (state.filter.sort === 'model' ? ' selected' : '') + '>' + t('sort_model') + '</option>' +
      '<option value="ip"' + (state.filter.sort === 'ip' ? ' selected' : '') + '>' + t('sort_ip') + '</option>' +
      '</select></div></div>' +
      '<div class="count-note">' + t('showing', { n: list.length, t: PRODUCTS.length }) + '</div>' +
      (list.length ? '<div class="prod-grid">' + list.map(prodCard).join('') + '</div>'
        : '<div class="empty-state"><p>' + t('no_results') + '</p><button class="btn btn-ghost" data-reset style="margin-top:16px">' + t('reset_filters') + '</button></div>') +
      '</div></section>';
  }

  function filterList() {
    var f = state.filter;
    var out = PRODUCTS.filter(function (p) {
      if (f.cat !== 'all' && p.cat !== f.cat) return false;
      if (f.ip !== 'all' && p.ip !== f.ip) return false;
      if (f.q) {
        var hay = (p.model + ' ' + p.codes.join(' ') + ' ' + p.ip + ' ' + p.cat + ' ' + p.catName).toLowerCase();
        if (hay.indexOf(f.q.toLowerCase()) < 0) return false;
      }
      return true;
    });
    if (f.sort === 'model') out.sort(function (a, b) { return a.model.localeCompare(b.model); });
    if (f.sort === 'ip') out.sort(function (a, b) { return a.ip.localeCompare(b.ip); });
    return out;
  }

  function specRow(label, val) {
    if (!val) return '';
    return '<div class="spec-row"><dt>' + esc(label) + '</dt><dd>' + esc(val) + '</dd></div>';
  }

  function viewProduct(id) {
    var p = prodById(id);
    if (!p) return '<section class="section"><div class="wrap empty-state">404</div></section>';
    var zh = state.lang === 'zh';
    var related = PRODUCTS.filter(function (x) { return x.cat === p.cat && x.id !== p.id; }).slice(0, 4);
    var main = p.images[0] || '';
    return '<section class="section tight"><div class="wrap">' +
      '<div class="breadcrumb"><a href="' + url('') + '">' + t('bc_home') + '</a>' + I.chev +
      '<a href="' + url('products') + '">' + t('bc_products') + '</a>' + I.chev +
      '<a href="' + url('products') + '?cat=' + p.cat + '">' + esc(catName(p.cat)) + '</a>' + I.chev +
      '<span>' + esc(p.model) + '</span></div>' +
      '<div class="pd">' +
      '<div class="gallery">' +
      '<div class="gallery-main"><img id="galMain" src="' + main + '" alt="' + esc(p.model) + '"></div>' +
      (p.images.length > 1 ? '<div class="gallery-thumbs">' + p.images.map(function (im, i) {
        return '<button class="' + (i === 0 ? 'on' : '') + '" data-gal="' + im + '"><img src="' + im + '" alt=""></button>';
      }).join('') + '</div>' : '') +
      '</div>' +
      '<div>' +
      '<span class="eyebrow">' + esc(catName(p.cat)) + '</span>' +
      '<h1 class="pd-title" style="margin-top:12px">' + esc(p.model) + '</h1>' +
      '<div class="pd-sub">' + esc(p.codes.join('  ·  ')) + '</div>' +
      '<div class="prod-tags" style="position:static;margin-top:16px">' +
      '<span class="tag ip">' + esc(p.ip) + '</span>' +
      (p.voltage ? '<span class="tag">' + esc(p.voltage) + '</span>' : '') +
      '<span class="tag">' + esc(catName(p.cat)) + '</span></div>' +
      '<div class="pd-price-note">' + I.doc + '<p><b>' + t('price_note_title') + '</b><br>' + t('price_note_body') + '</p></div>' +
      '<div class="pd-cta">' +
      '<button class="btn btn-primary btn-lg" data-add="' + p.id + '">' + I.cart + t('add_inquiry') + '</button>' +
      '<a class="btn btn-ghost btn-lg" href="' + url('quote') + '">' + t('buy_now') + I.arrow + '</a>' +
      '<a class="btn btn-dark btn-lg" href="' + waLink('Hi Karylite, please quote ' + p.model + ' (' + p.codes.join(', ') + ').') + '" target="_blank" rel="noopener">' + I.wa + ' WhatsApp</a>' +
      '</div>' +
      '<dl class="spec-table">' +
      specRow(t('spec_ip'), p.ip) +
      specRow(t('spec_cat'), catName(p.cat)) +
      specRow(t('spec_power'), p.power) +
      specRow(t('spec_voltage'), p.voltage) +
      specRow(t('spec_cct'), t('cct_value')) +
      specRow(t('spec_control'), t('control_value')) +
      specRow(zh && p.materialZh ? '外壳材料' : t('spec_material'), zh && p.materialZh ? p.materialZh : p.material) +
      specRow(zh && p.dimsZh ? '尺寸' : t('spec_dims'), zh && p.dimsZh ? p.dimsZh : p.dims) +
      specRow(zh && p.distZh ? '配光方案' : t('spec_dist'), zh && p.distZh ? p.distZh : p.dist) +
      specRow(zh && p.supplyZh ? '电源' : t('spec_supply'), zh && p.supplyZh ? p.supplyZh : p.supply) +
      specRow(zh && p.accessoryZh ? '配件' : t('spec_accessory'), zh && p.accessoryZh ? p.accessoryZh : p.accessory) +
      specRow(t('spec_remark'), zh && p.remarkZh ? p.remarkZh : p.remark) +
      specRow(t('spec_warranty'), t('warranty_value')) +
      '</dl>' +
      '<div style="margin-top:16px"><div class="small muted" style="margin-bottom:8px">' + t('spec_codes') + '</div>' +
      '<div class="code-pills">' + p.codes.map(function (c) { return '<span class="code-pill">' + esc(c) + '</span>'; }).join('') + '</div></div>' +
      '<p class="small muted" style="margin-top:20px;display:flex;gap:8px;align-items:center">' + I.doc + t('datasheet') + '</p>' +
      '</div></div>' +
      (related.length ? '<div style="margin-top:80px"><h2 class="h2" style="margin-bottom:22px">' + t('related') + '</h2>' +
        '<div class="prod-grid">' + related.map(prodCard).join('') + '</div></div>' : '') +
      '</div></section>';
  }

  function viewSolutions() {
    var apps = [
      ['app_pool', 'assets/img/scene/app-pool.jpg'], ['app_garden', 'assets/img/scene/app-garden.jpg'],
      ['app_facade', 'assets/img/scene/app-facade.jpg'], ['app_path', 'assets/img/scene/app-path.jpg'],
      ['app_hotel', 'assets/img/scene/app-wall.jpg'], ['app_fountain', 'assets/img/scene/app-fountain.jpg'],
      ['app_water', 'assets/img/scene/app-water.jpg']
    ];
    var map = { app_pool: 'underwater', app_garden: 'spot', app_facade: 'linear', app_path: 'inground', app_hotel: 'step', app_fountain: 'underwater' };
    return '<section class="section tight"><div class="wrap">' +
      '<div class="section-head"><span class="eyebrow">' + t('app_eyebrow') + '</span>' +
      '<h1 class="h1">' + t('app_title') + '</h1><p class="lead">' + t('app_sub') + '</p></div>' +
      '<div class="app-grid">' + apps.filter(function (a) { return a[0] !== 'app_water'; }).map(function (a) {
        return '<a class="app-card reveal" href="' + url('products') + '?cat=' + (map[a[0]] || 'all') + '">' +
          '<img src="' + a[1] + '" alt="" loading="lazy">' +
          '<div class="app-card-body"><h3>' + t(a[0]) + '</h3><p>' + t(a[0] + '_d') + '</p></div></a>';
      }).join('') + '</div>' +
      '<div class="split" style="margin-top:80px">' +
      '<div class="split-img"><img src="assets/img/scene/project-night.jpg" alt="Karylite project reference — waterfront lighting" loading="lazy"></div>' +
      '<div><span class="eyebrow">' + t('why_eyebrow') + '</span><h2 class="h1" style="margin:14px 0">' + t('why_title') + '</h2>' +
      '<p class="lead">' + t('why_sub') + '</p>' +
      '<div class="pd-cta"><a class="btn btn-primary" href="' + url('quote') + '">' + t('cta_btn') + I.arrow + '</a></div></div>' +
      '</div></div></section>';
  }

  /* 真实工厂实拍（提取自 2026 产品目录 P2–P3） */
  var FACTORY_SHOTS = [
    { img: 'assets/img/factory/building.jpg', k: 'fty_g1' },
    { img: 'assets/img/factory/workshop.jpg', k: 'fty_g2' },
    { img: 'assets/img/factory/lab.jpg', k: 'fty_g3' },
    { img: 'assets/img/factory/aging.jpg', k: 'fty_g4' },
    { img: 'assets/img/factory/optic.jpg', k: 'fty_g5' },
    { img: 'assets/img/factory/warehouse.jpg', k: 'fty_g6' },
    { img: 'assets/img/scene/beam.jpg', k: 'fty_g7' }
  ];

  function viewFactory() {
    var items = [['fty_1', 'fty_1d'], ['fty_2', 'fty_2d'], ['fty_3', 'fty_3d'], ['fty_4', 'fty_4d']];
    return '<section class="section tight"><div class="wrap">' +
      '<div class="section-head"><span class="eyebrow">' + t('fty_eyebrow') + '</span>' +
      '<h1 class="h1">' + t('fty_title') + '</h1><p class="lead">' + t('fty_sub') + '</p></div>' +

      /* 厂区 / 车间 / 实验室实拍 */
      '<div class="shot-grid">' + FACTORY_SHOTS.map(function (s) {
        return '<figure class="shot reveal"><img src="' + s.img + '" alt="' + esc(t(s.k)) + '" loading="lazy">' +
          '<figcaption><h3>' + t(s.k) + '</h3><p>' + t(s.k + 'd') + '</p></figcaption></figure>';
      }).join('') + '</div>' +

      /* 品控要点 */
      '<div class="feat-grid" style="margin:64px 0 60px">' + items.map(function (x) {
        return '<div class="feat reveal"><h3>' + t(x[0]) + '</h3><p>' + t(x[1]) + '</p></div>';
      }).join('') + '</div>' +

      '<div class="split">' +
      '<div><span class="eyebrow">' + t('about_eyebrow') + '</span>' +
      '<h2 class="h1" style="margin:14px 0">' + t('about_title') + '</h2>' +
      '<p class="lead">' + t('about_p1') + '</p><p class="lead" style="margin-top:16px">' + t('about_p2') + '</p>' +
      '<div class="stat-grid">' +
      [['stat_val_1', 'stat_1'], ['stat_val_2', 'stat_2'], ['stat_val_3', 'stat_3'], ['stat_val_4', 'stat_4']].map(function (s) {
        return '<div class="stat"><b>' + t(s[0]) + '</b><span>' + t(s[1]) + '</span></div>';
      }).join('') + '</div></div>' +
      '<div class="split-img" style="aspect-ratio:4/5"><img src="assets/img/factory/workshop.jpg" alt="Karylite production floor" loading="lazy"></div>' +
      '</div></div></section>' + ctaSection();
  }

  function viewAbout() { return viewFactory(); }

  function ctaSection() {
    return '<section class="section tight"><div class="wrap"><div class="cta-band"><div class="cta-band-inner">' +
      '<div><h2>' + t('cta_title') + '</h2><p>' + t('cta_sub') + '</p></div>' +
      '<div style="display:flex;gap:11px;flex-wrap:wrap"><a class="btn btn-primary btn-lg" href="' + url('quote') + '">' + t('cta_btn') + I.arrow + '</a></div>' +
      '</div></div></div></section>';
  }

  function viewContact() {
    return '<section class="section tight"><div class="wrap">' +
      '<div class="section-head"><span class="eyebrow">' + t('nav_contact') + '</span>' +
      '<h1 class="h1">' + t('contact_h1') + '</h1><p class="lead">' + t('contact_sub') + '</p></div>' +
      '<div class="contact-grid">' +
      '<div>' +
      contactItem('pin', t('c_address'), address()) +
      contactItem('phone', t('c_tel'), '<a href="tel:' + CFG.telHref + '">' + CFG.tel + '</a>') +
      contactItem('wa', t('c_whatsapp'), '<a href="' + waLink('Hello Karylite!') + '" target="_blank" rel="noopener">+' + CFG.whatsapp + '</a>') +
      contactItem('chat', t('c_wechat'), CFG.wechat) +
      contactItem('mail', t('c_email'), '<a href="mailto:' + CFG.email + '">' + CFG.email + '</a>') +
      contactItem('globe', t('c_web'), '<a href="https://' + CFG.web + '" target="_blank" rel="noopener">' + CFG.web + '</a>') +
      contactItem('doc', t('c_hours'), t('c_hours_v')) +
      '</div>' +
      '<div class="bank-card">' +
      '<h3 style="font-size:18px;margin-bottom:16px">' + t('send_message') + '</h3>' +
      '<form id="contactForm" class="form-grid">' +
      '<div class="form-field"><label>' + t('f_company') + ' <span class="req">*</span></label><input name="company" required></div>' +
      '<div class="form-field"><label>' + t('f_name') + ' <span class="req">*</span></label><input name="name" required></div>' +
      '<div class="form-field"><label>' + t('f_email') + ' <span class="req">*</span></label><input type="email" name="email" required></div>' +
      '<div class="form-field"><label>' + t('f_country') + '</label><input name="country"></div>' +
      '<div class="form-field full"><label>' + t('f_message') + '</label><textarea name="message" placeholder="' + esc(t('f_message_ph')) + '"></textarea></div>' +
      '<div class="form-field full"><button class="btn btn-primary btn-lg btn-block" type="submit">' + I.mail + t('send_message') + '</button></div>' +
      '</form></div></div>' +

      /* 扫码联系 —— 二维码提取自产品目录最后一页 */
      '<div class="qr-band">' +
      '<div class="qr-intro"><h2 class="h1" style="font-size:clamp(24px,2.6vw,34px)">' + t('qr_title') + '</h2>' +
      '<p class="lead">' + t('qr_sub') + '</p>' +
      '<ul class="qr-list">' +
      '<li>' + I.phone + '<a href="tel:' + CFG.telHref + '">' + CFG.tel + '</a></li>' +
      '<li>' + I.mail + '<a href="mailto:' + CFG.email + '">' + CFG.email + '</a></li>' +
      '<li>' + I.chat + '<span>WeChat: ' + esc(CFG.wechat) + '</span></li>' +
      '<li>' + I.globe + '<a href="https://' + CFG.web + '" target="_blank" rel="noopener">' + CFG.web + '</a></li>' +
      '</ul></div>' +
      '<div class="qr-cards">' +
      '<figure class="qr-card"><img src="assets/img/contact/whatsapp-qr.png" alt="WhatsApp QR code" loading="lazy">' +
      '<figcaption><span>' + t('qr_wa') + '</span><b>+' + CFG.whatsapp + '</b></figcaption></figure>' +
      '<figure class="qr-card"><img src="assets/img/contact/wechat-qr.png" alt="WeChat QR code" loading="lazy">' +
      '<figcaption><span>' + t('qr_wechat') + '</span><b>' + esc(CFG.wechat) + '</b></figcaption></figure>' +
      '</div></div>' +
      '</div></section>';
  }
  function contactItem(ic, label, val) {
    return '<div class="contact-item"><div class="ci-ico">' + I[ic] + '</div><div><b>' + esc(label) + '</b>' + val + '</div></div>';
  }

  /* ------------------------------------------------------------ QUOTE VIEW */
  function viewQuote() {
    var items = state.inquiry.map(function (x) {
      var p = prodById(x.id);
      return p ? { p: p, qty: x.qty } : null;
    }).filter(Boolean);
    var methods = payMethods();
    var chosen = methods.filter(function (m) { return m.id === state.payMethod; })[0] || methods[0];

    return '<section class="section tight"><div class="wrap">' +
      '<div class="section-head" style="margin-bottom:26px"><span class="eyebrow">' + t('nav_payment') + '</span>' +
      '<h1 class="h1">' + t('quote_title') + '</h1><p class="lead">' + t('quote_sub') + '</p></div>' +

      '<div class="steps-nav">' +
      stepNav(1, 'step_1') + stepNav(2, 'step_2') + stepNav(3, 'step_3') +
      '</div>' +

      '<div class="quote-grid">' +
      '<div>' +
      /* --- step 1 : list --- */
      '<div class="bank-card" style="margin-bottom:22px">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px">' +
      '<h3 style="font-size:17px">' + t('step_1') + '</h3>' +
      (items.length ? '<button class="btn btn-ghost btn-sm" data-clear>' + I.trash + t('clear_all') + '</button>' : '') +
      '</div>' +
      (items.length ? items.map(function (it) {
        return '<div class="line-item">' +
          '<img src="' + (it.p.images[0] || '') + '" alt="">' +
          '<div><div class="prod-model" style="font-size:15px">' + esc(it.p.model) + '</div>' +
          '<div class="small muted">' + esc(catName(it.p.cat)) + ' · ' + esc(it.p.ip) + '</div>' +
          '<div class="small muted">' + esc(it.p.codes[0] || '') + '</div></div>' +
          '<div style="display:flex;align-items:center;gap:12px">' +
          '<div class="qty"><button data-q="-1" data-id="' + it.p.id + '">−</button>' +
          '<input type="number" min="1" value="' + it.qty + '" data-qty="' + it.p.id + '">' +
          '<button data-q="1" data-id="' + it.p.id + '">+</button></div>' +
          '<button class="icon-btn" data-del="' + it.p.id + '" title="' + esc(t('remove')) + '">' + I.trash + '</button>' +
          '</div></div>';
      }).join('') : '<div class="empty-state" style="padding:40px 10px"><p>' + t('empty_inquiry') + '</p>' +
        '<a class="btn btn-ghost" href="' + url('products') + '" style="margin-top:14px">' + t('empty_inquiry_cta') + '</a></div>') +
      '</div>' +

      /* --- step 2 : buyer --- */
      '<div class="bank-card" style="margin-bottom:22px">' +
      '<h3 style="font-size:17px;margin-bottom:16px">' + t('step_2') + ' · ' + t('buyer_info') + '</h3>' +
      '<form id="quoteForm" class="form-grid">' +
      '<div class="form-field"><label>' + t('f_company') + ' <span class="req">*</span></label><input name="company" required></div>' +
      '<div class="form-field"><label>' + t('f_name') + ' <span class="req">*</span></label><input name="name" required></div>' +
      '<div class="form-field"><label>' + t('f_email') + ' <span class="req">*</span></label><input type="email" name="email" required></div>' +
      '<div class="form-field"><label>' + t('f_phone') + '</label><input name="phone"></div>' +
      '<div class="form-field"><label>' + t('f_country') + '</label><input name="country"></div>' +
      '<div class="form-field"><label>' + t('f_incoterm') + '</label><select name="incoterm">' +
      ['EXW', 'FOB Shenzhen', 'CIF', 'DDP', 'DAP'].map(function (x) { return '<option>' + x + '</option>'; }).join('') +
      '</select></div>' +
      '<div class="form-field full"><label>' + t('f_message') + '</label><textarea name="message" placeholder="' + esc(t('f_message_ph')) + '"></textarea></div>' +
      '<div class="form-field full"><button class="btn btn-primary btn-lg btn-block" type="submit">' + I.mail + t('submit_inquiry') + '</button></div>' +
      '</form></div>' +

      /* --- step 3 : payment --- */
      '<div class="bank-card">' +
      '<h3 style="font-size:17px;margin-bottom:6px">' + t('step_3') + ' · ' + t('payment_h1') + '</h3>' +
      '<p class="small muted" style="margin-bottom:18px">' + t('pay_choose') + '</p>' +
      '<div class="pay-methods cols-2">' +
      methods.map(function (m) {
        return '<div class="pay-card" style="padding:18px' + (m.id === state.payMethod ? ';border-color:var(--accent)' : '') + '">' +
          '<div class="pay-card-head"><div class="pay-logo">' + m.icon + '</div>' +
          '<div><h3>' + t(m.title) + '</h3><div class="pc-sub">' + (m.sub || '') + '</div></div></div>' +
          '<p>' + t(m.desc) + '</p>' +
          '<button class="btn ' + (m.id === state.payMethod ? 'btn-primary' : 'btn-ghost') + ' btn-sm" data-method="' + m.id + '">' +
          (m.id === state.payMethod ? t('pay_now') : t('pay_choose')) + '</button></div>';
      }).join('') + '</div>' +
      '<div class="pd-cta" style="margin-top:22px">' +
      '<button class="btn btn-primary btn-lg" data-paydeposit="30">' + I.lock + t('pay_deposit') + '</button>' +
      '<button class="btn btn-ghost btn-lg" data-paydeposit="100">' + t('pay_full') + '</button>' +
      '</div>' +
      '<div class="ssl-note" style="margin-top:18px">' + I.lock + '<span><b>' + t('secure') + '</b> — ' + t('secure_note') + '</span></div>' +
      '<div class="card-brand-row" style="margin-top:18px">' +
      '<span class="card-brand paypal">PayPal</span><span class="card-brand visa">VISA</span>' +
      '<span class="card-brand mc">Mastercard</span><span class="card-brand amex">AMEX</span>' +
      '<span class="card-brand jcb">JCB</span><span class="card-brand unionpay">UnionPay</span>' +
      '<span class="card-brand" style="background:var(--surface-2);color:var(--muted)">T/T</span></div>' +
      '</div>' +
      '</div>' +

      /* --- summary --- */
      '<aside class="summary">' +
      '<h3>' + t('order_summary') + '</h3>' +
      '<div class="sum-row"><span>' + t('step_1') + '</span><span>' + t('items_count', { n: items.length }) + '</span></div>' +
      '<div class="sum-row"><span>' + t('deposit') + '</span><span class="mono">30%</span></div>' +
      '<div class="sum-row"><span>' + t('balance') + '</span><span class="mono">70%</span></div>' +
      '<div class="sum-row"><span>' + t('sum_method') + '</span><span style="color:var(--accent)">' + t(chosen.title) + '</span></div>' +
      '<div class="sum-row total"><span>' + t('pay_deposit') + '</span><b>' + t('secure') + '</b></div>' +
      '<p class="tiny muted" style="margin-top:14px">' + t('summary_note') + '</p>' +
      '<div class="divider" style="margin:18px 0"></div>' +
      '<div class="bank-row"><span>' + t('t_terms') + '</span><b>' + t('t_terms_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_moq') + '</span><b>' + t('t_moq_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_lead') + '</span><b>' + t('t_lead_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_sample') + '</span><b>' + t('t_sample_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_warranty') + '</span><b>' + t('t_warranty_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_incoterm') + '</span><b>' + t('t_incoterm_v') + '</b></div>' +
      '</aside>' +
      '</div></div></section>';
  }

  function stepNav(n, key) {
    var cls = state.step === n ? 'on' : (state.step > n ? 'done' : '');
    return '<div class="' + cls + '"><i>' + (state.step > n ? '✓' : n) + '</i>' + t(key) + '</div>';
  }

  function payMethods() {
    return [
      { id: 'bank', title: 'pay_3', desc: 'pay_3d', icon: I.bank, sub: 'USD / EUR / CNY' },
      { id: 'card', title: 'pay_2', desc: 'pay_2d', icon: I.card, sub: 'Stripe · PCI-DSS L1', rec: true },
      { id: 'paypal', title: 'pay_1', desc: 'pay_1d', icon: I.paypal, sub: 'Instant' },
      { id: 'wise', title: 'pay_5', desc: 'pay_5d', icon: I.wise, sub: 'Multi-currency' },
      { id: 'wu', title: 'pay_4', desc: 'pay_4d', icon: I.wu, sub: '200+ countries' },
      { id: 'lc', title: 'pay_6', desc: 'pay_6d', icon: I.doc, sub: 'At sight' }
    ];
  }

  /* --------------------------------------------------------- PAYMENT VIEW */
  function viewPayment() {
    var m = payMethods();
    var flow = [['flow_1', 'flow_1d'], ['flow_2', 'flow_2d'], ['flow_3', 'flow_3d'], ['flow_4', 'flow_4d']];
    var b = CFG.pay.bank;
    return '<section class="pay-hero"><div class="wrap">' +
      '<span class="eyebrow">' + t('secure') + '</span>' +
      '<h1 class="h1" style="margin:14px 0 12px">' + t('payment_h1') + '</h1>' +
      '<p class="lead" style="max-width:720px">' + t('payment_sub') + '</p>' +
      '<div class="ssl-note" style="margin-top:20px">' + I.lock + '<span>' + t('secure_note') + '</span></div>' +
      '</div></section>' +

      '<section class="section"><div class="wrap">' +
      '<div class="pay-methods">' + m.map(function (x) {
        return '<div class="pay-card">' + (x.rec ? '<span class="pay-rec">' + t('recommended') + '</span>' : '') +
          '<div class="pay-card-head"><div class="pay-logo">' + x.icon + '</div>' +
          '<div><h3>' + t(x.title) + '</h3><div class="pc-sub">' + (x.sub || '') + '</div></div></div>' +
          '<p>' + t(x.desc) + '</p>' +
          '<div class="pay-tags">' + tagsFor(x.id).map(function (s) { return '<span>' + s + '</span>'; }).join('') + '</div>' +
          '<button class="btn btn-primary" data-pay="' + x.id + '">' + I.lock + t(payAction(x.id)) + '</button>' +
          '</div>';
      }).join('') + '</div>' +

      '<div class="section-head" style="margin:70px 0 30px"><h2 class="h1">' + t('pay_flow') + '</h2></div>' +
      '<div class="pay-steps">' + flow.map(function (f) {
        return '<div class="pay-step"><h3>' + t(f[0]) + '</h3><p>' + t(f[1]) + '</p></div>';
      }).join('') + '</div>' +

      '<div class="split" style="margin-top:70px;align-items:start">' +
      '<div class="bank-card">' +
      '<h3 style="font-size:18px;margin-bottom:14px">' + I.bank + ' ' + t('bank_title') + '</h3>' +
      bankRows() +
      '<button class="btn btn-ghost btn-block" style="margin-top:18px" data-copy-bank>' + I.doc + t('bank_copy_all') + '</button>' +
      '<p class="tiny muted" style="margin-top:16px">' + t('bank_note') + '</p>' +
      '</div>' +
      '<div>' +
      '<h3 style="font-size:18px;margin-bottom:14px">' + t('terms_title') + '</h3>' +
      '<div class="bank-row"><span>' + t('t_terms') + '</span><b>' + t('t_terms_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_moq') + '</span><b>' + t('t_moq_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_lead') + '</span><b>' + t('t_lead_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_sample') + '</span><b>' + t('t_sample_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_warranty') + '</span><b>' + t('t_warranty_v') + '</b></div>' +
      '<div class="bank-row"><span>' + t('t_incoterm') + '</span><b>' + t('t_incoterm_v') + '</b></div>' +
      '<div class="pd-cta"><a class="btn btn-primary btn-lg" href="' + url('quote') + '">' + t('cta_btn') + I.arrow + '</a></div>' +
      '</div></div></div></section>';
  }

  function tagsFor(id) {
    return {
      bank: ['T/T', 'SWIFT', 'Any currency'], card: ['Visa', 'Mastercard', 'AMEX', 'JCB', 'UnionPay'],
      paypal: ['Buyer protection', 'Instant'], wise: ['Low fee', 'Mid-market rate'],
      wu: ['Cash pickup', 'No bank needed'], lc: ['At sight', 'Bank-issued']
    }[id] || [];
  }
  function payAction(id) {
    return { bank: 'pay_wu', card: 'pay_now', paypal: 'pay_now', wise: 'pay_now', wu: 'pay_wu', lc: 'pay_lc' }[id] || 'pay_now';
  }
  function bankRow(k, v, wide) {
    return '<div class="bank-row' + (wide ? ' wide' : '') + '"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>';
  }

  /* T/T 收款信息：银行端要求名称与标点保持完整，逐行展示 + 一键整段复制 */
  function bankRows() {
    var b = CFG.pay.bank;
    return bankRow(t('bank_beneficiary'), b.beneficiary) +
      bankRow(t('bank_bene_addr'), b.beneficiaryAddress, true) +
      bankRow(t('bank_name'), b.bankName, true) +
      bankRow(t('bank_bank_addr'), b.bankAddress, true) +
      bankRow(t('bank_account'), b.account) +
      bankRow(t('bank_swift'), b.swift);
  }
  function bankText() {
    var b = CFG.pay.bank;
    return 'T/T account\n' +
      'Beneficiary name: ' + b.beneficiary + '\n' +
      'Beneficiary address: ' + b.beneficiaryAddress + '\n' +
      'Name of bank: ' + b.bankName + '\n' +
      'Bank address: ' + b.bankAddress + '\n' +
      'Account of bank: ' + b.account + '\n' +
      'Swift code: ' + b.swift;
  }

  /* --------------------------------------------------------- PAYMENT MODAL */
  function openPayment(methodId, pct) {
    var m = payMethods().filter(function (x) { return x.id === methodId; })[0] || payMethods()[0];
    var b = CFG.pay.bank;
    var reference = ref('KRLINV');
    var amount = pct === 100 ? '' : '';
    var status = payStatus(methodId);
    var body =
      '<button class="modal-close" data-close>' + I.close + '</button>' +
      '<div class="pay-card-head" style="margin-bottom:14px"><div class="pay-logo" style="width:56px;height:44px">' + m.icon + '</div>' +
      '<div><h3 style="margin:0">' + t('modal_pay_title') + '</h3>' +
      '<div class="small muted">' + t(m.title) + ' · ' + t('modal_pay_sub', { ref: reference }) + '</div></div></div>' +
      (pct ? '<div style="margin-bottom:6px"><span class="tag ip">' + (pct === 100 ? t('pay_full') : t('deposit') + ' · 30%') + '</span></div>' : '') +
      '<label class="small muted" style="display:block;margin:14px 0 6px">' + t('amount') + '</label>' +
      '<div class="copy-row"><input class="amount-input" id="payAmount" type="number" min="1" placeholder="0.00" value="' + amount + '"></div>' +
      '<div class="amount-presets">' + [500, 1000, 5000, 10000].map(function (v) {
        return '<button data-amt="' + v + '">$' + v.toLocaleString('en-US') + '</button>';
      }).join('') + '</div>' +
      '<div style="margin-top:22px">' + status + '</div>' +
      '<p class="tiny muted" style="margin-top:18px">' + t('modal_note') + '</p>' +
      '<div class="pd-cta" style="margin-top:18px">' +
      '<button class="btn btn-primary" data-paygo="' + methodId + '">' + I.lock + t('pay_now') + '</button>' +
      '<a class="btn btn-ghost" href="' + mailLink('Payment arrangement — ' + t(m.title), 'Hello Karylite,\n\nI would like to arrange payment for my order.\nReference: ' + reference + '\nMethod: ' + t(m.title) + '\n\nThanks.') + '">' + I.mail + t('modal_contact') + '</a>' +
      '</div>';
    openModal(body);
  }

  function payStatus(methodId) {
    var b = CFG.pay.bank;
    if (methodId === 'bank') {
      return '<div style="padding:16px;border:1px solid var(--line);border-radius:12px;background:var(--bg-2)">' +
        bankRows() +
        '<div class="copy-row"><input readonly value="' + esc(b.account) + '" id="copyVal"><button class="btn btn-ghost btn-sm" data-copy>' + t('copy') + '</button></div></div>';
    }
    if (methodId === 'wu') {
      return '<div style="padding:16px;border:1px solid var(--line);border-radius:12px;background:var(--bg-2)">' +
        bankRow('Receiver', CFG.pay.westernUnion.receiver) + bankRow('City', CFG.pay.westernUnion.city) +
        '<p class="tiny muted" style="margin-top:12px">' + t('modal_contact') + '</p></div>';
    }
    if (methodId === 'card') {
      return '<div class="card-brand-row"><span class="card-brand visa">VISA</span><span class="card-brand mc">Mastercard</span>' +
        '<span class="card-brand amex">AMEX</span><span class="card-brand jcb">JCB</span><span class="card-brand unionpay">UnionPay</span></div>' +
        '<div class="ssl-note" style="margin-top:14px">' + I.lock + '<span>' + t('secure_note') + '</span></div>';
    }
    return '<div class="ssl-note">' + I.shield + '<span>' + t('secure_note') + '</span></div>';
  }

  var PAY_KEY = { bank: 'pay_3', card: 'pay_2', paypal: 'pay_1', wise: 'pay_5', wu: 'pay_4', lc: 'pay_6' };

  function payGo(methodId) {
    var key = PAY_KEY[methodId] || 'pay_1';
    var conf = CFG.pay[methodId === 'wu' ? 'westernUnion' : methodId] || {};
    var amtEl = document.getElementById('payAmount');
    var amt = amtEl ? amtEl.value : '0';

    /* 已接入真实网关 —— 直接跳转（PayPal.me / Stripe Payment Link / Wise 收款页） */
    if (conf && conf.configured && conf.link) {
      window.open(conf.link, '_blank', 'noopener');
      return;
    }

    /* 未接入网关 —— 绝不静默失败：把付款意向连同询价单发到销售邮箱，线索不丢 */
    var methodName = t(key);
    var lines = state.inquiry.map(function (x) {
      var p = prodById(x.id);
      return p ? ('- ' + p.model + ' [' + (p.codes[0] || '') + '] x ' + x.qty) : '';
    }).join('\n');
    var body = 'Payment request from website\n\nMethod: ' + methodName + '\nAmount: USD ' + amt +
      '\n\nItems:\n' + (lines || '(see attached quotation)') +
      '\n\nPlease send payment instructions for this order.';
    closeModal();
    toast(t('pay_mail_hint'));
    setTimeout(function () {
      window.location.href = mailLink('Payment request - ' + methodName + ' - USD ' + amt, body);
    }, 700);
  }

  /* =============================================================== ROUTER = */
  /* 真实路径路由：/products/、/ar/product/step-10/
     同时保留 #/ 形式，供本地 file:// 双击预览与老链接兼容 */
  var LANGS = ['en', 'ar', 'zh', 'fr', 'es', 'ru'];

  /* 生成站内链接；file:// 下退回 hash 形式 */
  function url(p) {
    p = p || '';
    if (location.protocol === 'file:') return '#/' + p;
    var lp = (state.lang && state.lang !== 'en') ? '/' + state.lang : '';
    return lp + '/' + (p ? p + '/' : '');
  }

  function queryParse(s, q) {
    String(s || '').replace(/^\?/, '').split('&').forEach(function (kv) {
      if (!kv) return;
      var a = kv.split('=');
      q[decodeURIComponent(a[0])] = decodeURIComponent((a[1] || '').replace(/\+/g, ' '));
    });
    return q;
  }

  function routeFromLocation() {
    var q = {}, path;
    if (location.protocol === 'file:' || location.hash.indexOf('#/') === 0) {
      var h = location.hash.replace(/^#/, '');
      var qi = h.indexOf('?');
      if (qi >= 0) { queryParse(h.slice(qi + 1), q); h = h.slice(0, qi); }
      path = h;
    } else {
      path = location.pathname || '/';
      queryParse(location.search, q);
    }
    var seg = path.split('/').filter(Boolean);
    if (seg.length && /\.html?$/i.test(seg[seg.length - 1])) seg.pop();
    var lang = null;
    if (seg.length && LANGS.indexOf(seg[0]) >= 0) lang = seg.shift();
    return { lang: lang, parts: seg, q: q };
  }

  /* 站内跳转：优先 pushState；file:// 下退回 hash */
  function navigate(to) {
    if (!to) return;
    if (location.protocol === 'file:') {
      location.hash = to.charAt(0) === '#' ? to : '#' + to;
      return;
    }
    if (to === location.pathname + location.search) { render(); return; }
    try { history.pushState(null, '', to); } catch (e) { location.href = to; return; }
    render();
  }

  function render() {
    var r = routeFromLocation();
    /* 语言以 URL 为准：带语言前缀用该语言，不带前缀（英文根目录）一律按 en 渲染。
     *
     * 旧写法是 `if (r.lang && ...)`，只在 URL 带前缀时才纠正语言。结果英文路由
     * （/ /products/ /payment/ 等）的语言完全由访客浏览器决定：浏览器是中文系统，
     * 打开 www.krlite.com/payment/ 出来的是中文内容 + 英文站内链接，
     * 与页面 <html lang="en"> 和 hreflang 标注互相矛盾，搜索引擎会判为错配。
     *
     * 访客主动切语言时 setLang() 会跳到对应前缀的真实路径（/ar/、/zh/…），
     * 所以这里改成 URL 说了算之后，手动切换依然正常，且刷新不丢。
     */
    var wantLang = r.lang || 'en';
    if (LANGS.indexOf(wantLang) >= 0 && wantLang !== state.lang) {
      state.lang = wantLang;
      try { localStorage.setItem(LS_LANG, state.lang); } catch (e) {}
      paintLang(); applyStatic(); buildChrome(); bindChrome();
    }
    var p0 = r.parts[0] || 'home';
    if (r.q.cat) { state.filter.cat = r.q.cat; }
    var app = document.getElementById('app');
    var html = '';
    if (p0 === 'home') html = viewHome();
    else if (p0 === 'products') html = viewProducts();
    else if (p0 === 'product') html = viewProduct(r.parts[1]);
    else if (p0 === 'solutions') html = viewSolutions();
    else if (p0 === 'factory') html = viewFactory();
    else if (p0 === 'about') html = viewAbout();
    else if (p0 === 'contact') html = viewContact();
    else if (p0 === 'quote') html = viewQuote();
    else if (p0 === 'payment') html = viewPayment();
    else html = '<section class="section"><div class="wrap empty-state">404</div></section>';
    app.innerHTML = html;
    window.scrollTo({ top: 0, behavior: 'auto' });
    markNav(p0);
    revealInit();
    heroInit();

    /* deep links — handy for sales emails: #/product/step-10?add=1  ·  #/quote?modal=card&pct=30 */
    if (r.q.add && r.parts[1]) { addToInquiry(r.parts[1]); navigate(url('quote')); return; }
    if (r.q.modal) {
      var pct = parseInt(r.q.pct, 10) || 0;
      if (r.q.modal === 'true') openPayment(state.payMethod, pct || undefined);
      else openPayment(r.q.modal, pct || undefined);
    }
  }

  function markNav(p0) {
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      var k = a.getAttribute('data-nav');
      a.classList.toggle('active', k === p0 || (p0 === 'product' && k === 'products'));
    });
  }

  function heroInit() {
    var bg = document.getElementById('heroBg');
    if (!bg) return;
    var slides = bg.querySelectorAll('.slide');
    var dots = document.querySelectorAll('#heroDots button');
    var i = 0;
    if (bg._timer) clearInterval(bg._timer);
    bg._timer = setInterval(function () {
      slides[i].classList.remove('on'); if (dots[i]) dots[i].classList.remove('on');
      i = (i + 1) % slides.length;
      slides[i].classList.add('on'); if (dots[i]) dots[i].classList.add('on');
    }, 5200);
  }

  function revealInit() {
    var els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) { els.forEach(function (e) { e.classList.add('in'); }); return; }
    var io = new IntersectionObserver(function (ents) {
      ents.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -40px 0px', threshold: .06 });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ============================================================== EVENTS = */
  /* one-time bindings on persistent nodes */
  function bindOnce() {
    var hdr = document.querySelector('.header');
    window.addEventListener('scroll', function () {
      hdr.classList.toggle('scrolled', window.scrollY > 12);
      var top = document.querySelector('.fab-top');
      if (top) top.classList.toggle('show', window.scrollY > 700);
    }, { passive: true });

    document.addEventListener('click', function (e) {
      var lang = document.querySelector('.lang');
      if (lang && !lang.contains(e.target)) lang.classList.remove('open');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var sb = document.querySelector('.searchbox');
        if (sb) sb.classList.remove('open');
        closeModal();
      }
    });

    /* modal close */
    document.getElementById('modal').addEventListener('click', function (e) {
      if (e.target.classList.contains('modal-bg') || e.target.closest('[data-close]')) closeModal();
    });

    /* routed content delegation */
    document.getElementById('app').addEventListener('click', function (e) {
      var a = e.target.closest('[data-add]');
      if (a) { addToInquiry(a.getAttribute('data-add')); render(); return; }
      var del = e.target.closest('[data-del]');
      if (del) { removeItem(del.getAttribute('data-del')); return; }
      var q = e.target.closest('[data-q]');
      if (q) {
        var id = q.getAttribute('data-id');
        var cur = state.inquiry.filter(function (x) { return x.id === id; })[0];
        if (cur) setQty(id, cur.qty + parseInt(q.getAttribute('data-q'), 10));
        return;
      }
      var chip = e.target.closest('[data-cat]');
      if (chip) { state.filter.cat = chip.getAttribute('data-cat'); render(); return; }
      if (e.target.closest('[data-reset]')) {
        state.filter = { cat: 'all', ip: 'all', sort: 'default', q: '' }; render(); return;
      }
      if (e.target.closest('[data-clear]')) { state.inquiry = []; saveInquiry(); render(); return; }
      var gal = e.target.closest('[data-gal]');
      if (gal) {
        document.getElementById('galMain').src = gal.getAttribute('data-gal');
        gal.parentNode.querySelectorAll('button').forEach(function (b) { b.classList.remove('on'); });
        gal.classList.add('on'); return;
      }
      var meth = e.target.closest('[data-method]');
      if (meth) { state.payMethod = meth.getAttribute('data-method'); render(); return; }
      var pd = e.target.closest('[data-paydeposit]');
      if (pd) { openPayment(state.payMethod, parseInt(pd.getAttribute('data-paydeposit'), 10)); return; }
      var pay = e.target.closest('[data-pay]');
      if (pay) { openPayment(pay.getAttribute('data-pay')); return; }
      if (e.target.closest('[data-copy-bank]')) { copyText(bankText()); return; }
    });
    document.getElementById('app').addEventListener('change', function (e) {
      if (e.target.matches('[data-qty]')) { setQty(e.target.getAttribute('data-qty'), e.target.value); return; }
      if (e.target.matches('[data-ip]')) { state.filter.ip = e.target.value; render(); return; }
      if (e.target.matches('[data-sort]')) { state.filter.sort = e.target.value; render(); return; }
    });
    document.getElementById('app').addEventListener('submit', function (e) {
      e.preventDefault();
      var f = e.target;
      if (f.id !== 'quoteForm' && f.id !== 'contactForm') return;

      var data = {};
      new FormData(f).forEach(function (v, k) { data[k] = v; });
      var isQuote = (f.id === 'quoteForm');
      var lines = '', subject, body;

      if (isQuote) {
        lines = state.inquiry.map(function (x) {
          var p = prodById(x.id);
          return p ? ('- ' + p.model + ' [' + (p.codes[0] || '') + '] x ' + x.qty) : '';
        }).join('\n');
        body = 'Company: ' + (data.company || '') + '\nContact: ' + (data.name || '') + '\nEmail: ' + (data.email || '') +
          '\nPhone: ' + (data.phone || '') + '\nCountry/Port: ' + (data.country || '') + '\nIncoterm: ' + (data.incoterm || '') +
          '\n\nInquiry list:\n' + (lines || '(none)') + '\n\nRequirements:\n' + (data.message || '');
        subject = 'Quotation request - ' + (data.company || '');
      } else {
        lines = 'Company: ' + (data.company || '') + '\nContact: ' + (data.name || '') + '\nEmail: ' + (data.email || '') +
          '\nCountry: ' + (data.country || '') + '\n\nMessage:\n' + (data.message || '');
        body = lines;
        subject = 'Website inquiry - ' + (data.company || '');
      }

      var btn = f.querySelector('button[type="submit"]');
      var oldHtml = btn ? btn.innerHTML : '';

      /* 未配置收单地址：退回邮件方式（访客端需有邮件客户端，成功率低） */
      if (!CFG.formEndpoint) {
        state.mailto = mailLink(subject, body);
        window.location.href = state.mailto;
        toast(isQuote ? t('inquiry_sent') : t('msg_sent'));
        if (isQuote) { state.step = 3; render(); } else { f.reset(); }
        return;
      }

      /* 已配置收单地址：走 HTTP POST，访客端不依赖邮件客户端 */
      if (btn) { btn.disabled = true; btn.innerHTML = t('sending'); }
      var payload = {
        _subject: subject, subject: subject, form: f.id, page: location.href,
        company: data.company || '', name: data.name || '', email: data.email || '',
        phone: data.phone || '', country: data.country || '', incoterm: data.incoterm || '',
        message: data.message || '', inquiry: lines, _replyto: data.email || ''
      };
      if (CFG.formAccessKey) payload.access_key = CFG.formAccessKey;

      fetch(CFG.formEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload)
      }).then(function (r) {
        if (!r.ok) throw new Error(String(r.status));
        toast(t('msg_sent_ok'));
        if (isQuote) { state.inquiry = []; saveInquiry(); state.step = 3; render(); }
        else { f.reset(); }
      }).catch(function () {
        /* 提交失败兜底：退回邮件方式，不让客户白填一遍 */
        toast(t('msg_sent_fail'));
        setTimeout(function () {
          state.mailto = mailLink(subject, body);
          if (isQuote) { state.step = 3; render(); }
        }, 1200);
      }).then(function () {
        if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; }
      });
    });

    /* modal delegation (amount presets / copy / pay) */
    document.getElementById('modal').addEventListener('click', function (e) {
      var amt = e.target.closest('[data-amt]');
      if (amt) { document.getElementById('payAmount').value = amt.getAttribute('data-amt'); return; }
      if (e.target.closest('[data-copy]')) {
        var v = document.getElementById('copyVal');
        if (v) {
          try { v.select(); document.execCommand('copy'); } catch (err) {}
          if (navigator.clipboard && navigator.clipboard.writeText) {
            try { navigator.clipboard.writeText(v.value).catch(function () {}); } catch (err) {}
          }
          toast(t('copied'));
        }
        return;
      }
      var go = e.target.closest('[data-paygo]');
      if (go) { payGo(go.getAttribute('data-paygo')); return; }
    });
  }

  /* bindings that must be re-attached after the chrome is rebuilt */
  function bindChrome() {
    var lang = document.querySelector('.lang');
    var lb = document.querySelector('.lang-btn');
    if (lb) lb.addEventListener('click', function () { lang.classList.toggle('open'); });

    document.querySelectorAll('.lang-menu button').forEach(function (b) {
      b.addEventListener('click', function () { setLang(b.getAttribute('data-lang')); });
    });

    var drawer = document.querySelector('.drawer');
    var burger = document.querySelector('.burger');
    if (burger) burger.addEventListener('click', function () {
      drawer.classList.add('open'); document.body.style.overflow = 'hidden';
    });
    if (drawer && !drawer._bound) {
      drawer._bound = true;
      drawer.addEventListener('click', function (e) {
        if (e.target === drawer || e.target.closest('a')) {
          drawer.classList.remove('open'); document.body.style.overflow = '';
        }
      });
    }

    var sb = document.querySelector('.searchbox');
    var input = sb.querySelector('input');
    var opener = document.querySelector('.search-open');
    if (opener) opener.addEventListener('click', function () {
      sb.classList.add('open'); setTimeout(function () { input.focus(); }, 60);
    });
    sb.addEventListener('click', function (e) {
      if (e.target === sb) { sb.classList.remove('open'); input.value = ''; sb.querySelector('.search-results').innerHTML = ''; }
    });
    sb.querySelector('.search-results').addEventListener('click', function (e) {
      if (e.target.closest('a')) { sb.classList.remove('open'); input.value = ''; this.innerHTML = ''; }
    });
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      var res = sb.querySelector('.search-results');
      if (q.length < 2) { res.innerHTML = ''; return; }
      res.innerHTML = PRODUCTS.filter(function (p) {
        return (p.model + ' ' + p.codes.join(' ') + ' ' + p.ip + ' ' + p.catName).toLowerCase().indexOf(q) >= 0;
      }).slice(0, 8).map(function (p) {
        return '<a href="' + url('product/' + p.id) + '"><img src="' + p.images[0] + '" alt=""><div><b>' + esc(p.model) + '</b>' +
          '<div class="small muted">' + esc(catName(p.cat)) + ' · ' + esc(p.ip) + '</div></div></a>';
      }).join('') || '<div style="padding:16px" class="muted">' + t('no_results') + '</div>';
    });

    var fabTop = document.querySelector('.fab-top');
    if (fabTop) fabTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

    var nf = document.getElementById('newsForm');
    if (nf) nf.addEventListener('submit', function (e) { e.preventDefault(); toast(t('f_subscribed')); e.target.reset(); });
  }

  function setLang(l) {
    if (!window.I18N[l]) return;
    var r = routeFromLocation();
    var keep = r.parts.join('/');
    var qs = '';
    if (location.protocol !== 'file:' && location.search) qs = location.search;
    else if (location.hash.indexOf('?') >= 0) qs = '?' + location.hash.split('?')[1];
    state.lang = l;
    try { localStorage.setItem(LS_LANG, l); } catch (e) {}
    /* 语言切换 = 跳到该语言前缀的真实路径，URL 可被搜索引擎与收藏夹识别 */
    navigate(url(keep) + qs);
    refreshChrome();
  }

  function refreshChrome() {
    buildChrome();
    paintLang();
    applyStatic();
    paintBadge();
    bindChrome();
    render();
  }

  function paintLang() {
    var meta = window.I18N.meta[state.lang] || window.I18N.meta.en;
    document.querySelectorAll('.lang-btn .flag').forEach(function (e) { e.textContent = meta.flag; });
    document.querySelectorAll('.lang-btn .lbl').forEach(function (e) { e.textContent = state.lang.toUpperCase(); });
    document.querySelectorAll('.lang-menu button').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-lang') === state.lang);
    });
  }

  /* ================================================================== BOOT = */
  /* 站内 <a> 拦截：走 pushState，避免整页刷新 */
  function bindRouting() {
    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (!a || a.hasAttribute('download')) return;
      var tg = a.getAttribute('target');
      if (tg && tg !== '_self') return;
      var href = a.getAttribute('href') || '';
      if (!href) return;
      if (/^(mailto:|tel:|sms:|whatsapp:|javascript:)/i.test(href)) return;
      if (/^https?:\/\//i.test(href)) {
        if (location.protocol === 'http:' || location.protocol === 'https:') {
          if (href.indexOf(location.origin) !== 0) return;
          href = href.slice(location.origin.length);
        } else return;
      }
      if (href.charAt(0) !== '/') return;                    /* #anchor / 相对路径 */
      if (/\.(pdf|zip|rar|jpg|jpeg|png|webp|gif|svg|ico|txt|xml|json)$/i.test(href)) return;
      e.preventDefault();
      navigate(href);
    });
    window.addEventListener('popstate', function () { render(); });
  }

  /* 供构建期预渲染调用：静默切语言并重绘，不跳转 */
  window.__KL = {
    setLangSilent: function (l) {
      if (!window.I18N[l]) return false;
      state.lang = l;
      paintLang(); applyStatic(); buildChrome(); bindChrome(); render();
      return true;
    },
    render: function () { render(); },
    route: function () { return routeFromLocation(); },
    url: function (p) { return url(p); },
    lang: function () { return state.lang; }
  };

  function boot() {
    bindRouting();
    buildChrome();
    paintLang();
    applyStatic();
    paintBadge();
    bindOnce();
    bindChrome();
    render();
    window.addEventListener('hashchange', render);   /* file:// 预览与老 #/ 链接 */
  }

  function buildChrome() {
    var navItems = [['home', 'nav_home'], ['products', 'nav_products'], ['solutions', 'nav_solutions'],
      ['factory', 'nav_factory'], ['payment', 'nav_payment'], ['contact', 'nav_contact']];

    /* top bar */
    document.getElementById('topbar').innerHTML =
      '<div class="wrap"><div class="topbar-left">' +
      '<a href="mailto:' + CFG.email + '">' + I.mail + CFG.email + '</a>' +
      '<a href="' + waLink('Hello Karylite!') + '" target="_blank" rel="noopener">' + I.wa + '+' + CFG.whatsapp + '</a>' +
      '</div><div class="topbar-right"><span>' + t('top_shipping') + '</span>' +
      '<a href="' + 'https://' + CFG.web + '" target="_blank" rel="noopener">' + I.globe + CFG.web + '</a>' +
      '</div></div>';

    /* header */
    document.getElementById('header').innerHTML =
      '<div class="wrap">' +
      '<a class="logo" href="' + url('') + '">' +
      '<img class="logo-mark" src="assets/img/logo-mark.png" alt="KARYLITE" width="40" height="40">' +
      '<span class="logo-text"><img class="logo-word" src="assets/img/logo-word.png" alt="KARYLITE">' +
      '<span class="logo-tag">Outdoor Lighting</span></span></a>' +
      '<nav class="nav">' + navItems.map(function (n) {
        return '<a href="' + url(n[0] === 'home' ? '' : n[0]) + '" data-nav="' + n[0] + '">' + t(n[1]) + '</a>';
      }).join('') + '</nav>' +
      '<div class="header-actions">' +
      '<button class="icon-btn search-open" aria-label="' + esc(t('search')) + '">' + I.search + '</button>' +
      '<div class="lang"><button class="lang-btn">' + I.globe + '<span class="lbl">EN</span>' + I.down + '</button>' +
      '<div class="lang-menu">' + Object.keys(window.I18N.meta).map(function (k) {
        return '<button data-lang="' + k + '"><span>' + window.I18N.meta[k].flag + '</span>' + window.I18N.meta[k].name + '</button>';
      }).join('') + '</div></div>' +
      '<a class="icon-btn" href="' + url('quote') + '" aria-label="' + esc(t('top_inquiry')) + '">' + I.cart + '<span class="badge" data-inquiry-count hidden>0</span></a>' +
      '<a class="btn btn-primary btn-sm" href="' + url('quote') + '" style="display:none">' + t('cta_btn') + '</a>' +
      '<button class="icon-btn burger" aria-label="' + esc(t('menu')) + '">' + I.menu + '</button>' +
      '</div></div>';

    /* drawer */
    document.getElementById('drawer').innerHTML =
      '<div class="drawer-panel">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">' +
      '<img class="logo-word" src="assets/img/logo-word.png" alt="KARYLITE"><button class="icon-btn" onclick="document.querySelector(\'.drawer\').classList.remove(\'open\');document.body.style.overflow=\'\'">' + I.close + '</button></div>' +
      navItems.map(function (n) {
        return '<a href="' + url(n[0] === 'home' ? '' : n[0]) + '" data-nav="' + n[0] + '">' + t(n[1]) + '</a>';
      }).join('') +
      '<a class="btn btn-primary" href="' + url('quote') + '" style="margin-top:14px">' + t('cta_btn') + '</a>' +
      '<div class="lang-menu" style="position:static;opacity:1;visibility:visible;transform:none;box-shadow:none;background:transparent;border:0;padding:12px 0 0">' +
      Object.keys(window.I18N.meta).map(function (k) {
        return '<button data-lang="' + k + '"><span>' + window.I18N.meta[k].flag + '</span>' + window.I18N.meta[k].name + '</button>';
      }).join('') + '</div></div>';

    /* footer */
    document.getElementById('footer').innerHTML =
      '<div class="wrap"><div class="footer-grid">' +
      '<div class="footer-about"><div class="logo">' +
      '<img class="logo-full" src="assets/img/logo.png" alt="KARYLITE Outdoor Lighting" width="482" height="560"></div>' +
      '<p>' + t('f_about') + '</p>' +
      '<p style="margin-top:14px">' + esc(company()) + '<br>' + esc(address()) + '</p></div>' +
      '<div><h4>' + t('f_catalog') + '</h4><div class="footer-links">' +
      ['step', 'inground', 'spot', 'underwater', 'linear', 'downlight'].map(function (c) {
        return '<a href="' + url('products') + '?cat=' + c + '">' + esc(catName(c)) + '</a>';
      }).join('') + '</div></div>' +
      '<div><h4>' + t('f_quick') + '</h4><div class="footer-links">' +
      navItems.map(function (n) { return '<a href="' + url(n[0] === 'home' ? '' : n[0]) + '">' + t(n[1]) + '</a>'; }).join('') +
      '</div></div>' +
      '<div><h4>' + t('f_getintouch') + '</h4><div class="footer-links">' +
      '<a href="mailto:' + CFG.email + '">' + CFG.email + '</a>' +
      '<a href="tel:' + CFG.telHref + '">' + CFG.tel + '</a>' +
      '<a href="' + waLink('Hello Karylite!') + '" target="_blank" rel="noopener">WhatsApp +' + CFG.whatsapp + '</a>' +
      '<a>' + t('c_wechat') + ': ' + CFG.wechat + '</a></div>' +
      '<h4 style="margin-top:24px">' + t('f_newsletter') + '</h4>' +
      '<form id="newsForm" style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">' +
      '<input class="field" required type="email" placeholder="' + esc(t('f_email_ph')) + '" style="flex:1;min-width:150px">' +
      '<button class="btn btn-primary btn-sm" type="submit">' + t('f_subscribe') + '</button></form></div>' +
      '</div>' +
      '<div class="footer-bottom"><span>' + t('f_rights') + '</span>' +
      '<div class="pay-logos"><span style="background:none;border:0;padding:0">' + t('f_payment') + '</span>' +
      ['PayPal', 'VISA', 'Mastercard', 'AMEX', 'JCB', 'UnionPay', 'T/T', 'Wise', 'L/C'].map(function (x) { return '<span>' + x + '</span>'; }).join('') +
      '</div>' +
      '<div style="display:flex;gap:16px"><a href="' + url('payment') + '">' + t('f_terms') + '</a><a href="' + url('payment') + '">' + t('f_shipping') + '</a></div>' +
      '</div></div>';

    /* floating */
    document.getElementById('floats').innerHTML =
      '<a class="fab wa" href="' + waLink('Hello Karylite, I would like to ask about your outdoor luminaires.') + '" target="_blank" rel="noopener" title="WhatsApp">' + I.wa + '</a>' +
      '<a class="fab mail" href="' + mailLink('Website inquiry', 'Hello Karylite,') + '" title="Email">' + I.mail + '</a>' +
      '<button class="fab fab-top" title="' + esc(t('back_top')) + '">' + I.up + '</button>';

    /* search box */
    document.getElementById('searchbox').innerHTML =
      '<div class="searchbox-inner"><input type="search" placeholder="' + esc(t('search_ph')) + '">' +
      '<div class="search-results"></div></div>';

  }

  document.addEventListener('DOMContentLoaded', boot);
})();
