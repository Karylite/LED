/* Karylite product data - auto generated from 2026 Catalogue */
window.KARYLITE_PRODUCTS = [
 {
  "id": "step-10",
  "page": 10,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1060H",
  "codes": [
   "LSL-1060H-BK"
  ],
  "ip": "IP65",
  "material": "Alu. Cover; AL, Body",
  "dims": "W60*L210*H37",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 1x3W / 2.2W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-10-0.jpg"
  ],
  "materialZh": "铝面盖 , 铝灯体",
  "dimsZh": "W60*L210*H37",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-12",
  "page": 12,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1080E/F",
  "codes": [
   "LSL-1080E-BK",
   "LSL-1080F-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL. Body",
  "dims": "Ø80*H59/W80*H59",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 1x3W / 2.1W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-12-0.jpg",
   "assets/img/products/step-12-1.jpg"
  ],
  "materialZh": "铝面盖 ; 铝灯体",
  "dimsZh": "Ø80*H59/W80*H59",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-14",
  "page": 14,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1145L",
  "codes": [
   "LSL-1145L-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "L145*W45*H43",
  "dist": "Diffuser,Frosted",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "1.8W / 6x0.5W / 1.5W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-14-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "L145*W45*H43",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-16",
  "page": 16,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1195L / 1328L",
  "codes": [
   "LSL-1195L-AS",
   "LSL-1328L-AS",
   "LSL-1195L-FR",
   "LSL-1328L-FR"
  ],
  "ip": "IP68",
  "material": "Alu.(SS316) Cover; AL. Body",
  "dims": "L195*W63*H65/L328*W63*H65",
  "dist": "Milky/Clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "DC24V 6W Optional/DC24V 12W Optional",
  "power": "5.6W / 6W / 12x0.5W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-16-0.jpg",
   "assets/img/products/step-16-1.jpg"
  ],
  "materialZh": "铝 ( 不锈钢 ) 面盖 ; 铝合金灯体",
  "dimsZh": "L195*W63*H65/L328*W63*H65",
  "distZh": "乳白 / 透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": "DC24V 6W 可选 /DC24V 12W 可选"
 },
 {
  "id": "step-18",
  "page": 18,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1330L",
  "codes": [
   "LSL-1330L-BK"
  ],
  "ip": "IP67",
  "material": "Alu. Cover; AL, Body",
  "dims": "L330*W125*H75",
  "dist": "Milly/clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "Could Use Inground",
  "power": "11.8W / 24x0.5W / 6x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-18-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "L330*W125*H75",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": "可用于地埋"
 },
 {
  "id": "step-20",
  "page": 20,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1080R/S",
  "codes": [
   "LSL-1080R-BK",
   "LSL-1080S-BK"
  ],
  "ip": "IP65",
  "material": "Alu Cover AL Rodu",
  "dims": "Ø80*H62/W80*H62",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 1x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-20-0.jpg",
   "assets/img/products/step-20-1.jpg"
  ],
  "materialZh": "铝面盖 ; 铝合金灯体",
  "dimsZh": "Ø80*H62/W80*H62",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-22",
  "page": 22,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1095R/S",
  "codes": [
   "LSL-1095R-BK",
   "LSL-1095S-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "Ø95*H50/W95*H50",
  "dist": "Diffuser,Frosted",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "1.8W / 6x0.5W / 1.2W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-22-0.jpg",
   "assets/img/products/step-22-1.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "Ø95*H50/W95*H50",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-24",
  "page": 24,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1102S",
  "codes": [
   "LSL-1102S-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "W102*H59",
  "dist": "Diffuser,Frosted",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 6x0.5W / 2.3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-24-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "W102*H59",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-26",
  "page": 26,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1118H/L",
  "codes": [
   "LSL-1118H-BK",
   "LSL-1118L-BK"
  ],
  "ip": "IP65",
  "material": "Alu. Cover; AL, Body",
  "dims": "W118*L173*H61/L173*W118*H61",
  "dist": "Diffuser,Frosted",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 18x0.2W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-26-0.jpg",
   "assets/img/products/step-26-1.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "W118*L173*H61/L173*W118*H61",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-28",
  "page": 28,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1170L",
  "codes": [
   "LSL-1170L-BK"
  ],
  "ip": "IP65",
  "material": "Alu. Cover; AL, Body",
  "dims": "L173*W118*H62",
  "dist": "Diffuser/clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "4W / 4x1W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-28-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "L173*W118*H62",
  "distZh": "扩散片，透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-30",
  "page": 30,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1120S/1160S",
  "codes": [
   "LSL-1120S-BK",
   "LSL-1160S-BK"
  ],
  "ip": "IP65",
  "material": "Alu. Cover; AL, Body",
  "dims": "W120*H75/W160*H65",
  "dist": "Diffuser/clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.8W / 18x0.2W / 32x0.2W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-30-0.jpg",
   "assets/img/products/step-30-1.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "W120*H75/W160*H65",
  "distZh": "扩散片，透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "step-34",
  "page": 34,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1150M/1150S",
  "codes": [
   "LSL-1150M-BK",
   "LSL-1150S-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "Ø150*H36/W150*H36",
  "dist": "Diffuser, Frosted",
  "supply": "Included",
  "accessory": "Wall Surface",
  "remark": "",
  "power": "5.8W / 9x1W / 6W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-34-0.jpg",
   "assets/img/products/step-34-1.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "Ø150*H36/W150*H36",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "挂墙明装",
  "remarkZh": ""
 },
 {
  "id": "step-36",
  "page": 36,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1215S",
  "codes": [
   "LSL-1215S-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "W215*H35",
  "dist": "Milly/clear",
  "supply": "Included",
  "accessory": "Wall Surface",
  "remark": "",
  "power": "9W / 9x1W / 12W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-36-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "W215*H35",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "挂墙明装",
  "remarkZh": "EN CH"
 },
 {
  "id": "step-38",
  "page": 38,
  "cat": "step",
  "catName": "Step Lights",
  "model": "1200L",
  "codes": [
   "LSL-1200L-BK"
  ],
  "ip": "IP54",
  "material": "Alu. Cover; AL, Body",
  "dims": "L200*W90*H36",
  "dist": "Milly/clear",
  "supply": "Included",
  "accessory": "Wall Surface",
  "remark": "",
  "power": "5.8W / 9x1W / 6W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/step-38-0.jpg"
  ],
  "materialZh": "铝面盖 : 铝灯体",
  "dimsZh": "L200*W90*H36",
  "distZh": "扩散片，乳白",
  "supplyZh": "内置",
  "accessoryZh": "挂墙明装",
  "remarkZh": "EN CH"
 },
 {
  "id": "inground-42",
  "page": 42,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2135R/2185R/2215R",
  "codes": [
   "IGL-2135R-CL",
   "IGL-2185R-CL",
   "IGL-2215R-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø135*H126/Ø185*H153/Ø215*H173",
  "dist": "Tempered Glas, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "9W / 21W / 36W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-42-0.jpg",
   "assets/img/products/inground-42-1.jpg",
   "assets/img/products/inground-42-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø135*H126/ Ø185*H153/Ø215*H173",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-44",
  "page": 44,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2135R/2185R/2215R -T",
  "codes": [
   "IGL-2135R-T",
   "IGL-2185R-T",
   "IGL-2215R-T"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø135*H126/Ø185*H153/Ø215*H173",
  "dist": "Tempered GIass,Clear",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "6W / 14W / 15W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-44-0.jpg",
   "assets/img/products/inground-44-1.jpg",
   "assets/img/products/inground-44-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø135*H126/ Ø185*H153/Ø215*H173",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "另配",
  "remarkZh": ""
 },
 {
  "id": "inground-46",
  "page": 46,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2135S/2185S/2215S",
  "codes": [
   "IGL-2135S-CL",
   "IGL-2185S-CL",
   "IGL-2215S-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W135*H126/W185*H153/W215*H173",
  "dist": "Tempered Glas, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "12W / 27W / 36W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-46-0.jpg",
   "assets/img/products/inground-46-1.jpg",
   "assets/img/products/inground-46-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "W135*H126/W185*H153/W215*H173",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-48",
  "page": 48,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2135S/2185S/2215S -T",
  "codes": [
   "IGL-2135S-T",
   "IGL-2185S-T",
   "IGL-2215S-T"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W135*H126/W185*H153/W215*H173",
  "dist": "Tempered GIass,Clear",
  "supply": "Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "8W / 6W / 18W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-48-0.jpg",
   "assets/img/products/inground-48-1.jpg",
   "assets/img/products/inground-48-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "W135*H126/ W185*H153/W215*H173",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-52",
  "page": 52,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2030G",
  "codes": [
   "IGL-2030G-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø30(Ø23)*H55",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "1W / 1x1W / 1.5W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/inground-52-0.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝合金灯体",
  "dimsZh": "Ø30(Ø23)*H55",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-54",
  "page": 54,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2048G",
  "codes": [
   "IGL-2048G-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø48(Ø32)*H55",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2W / 1x3W / 3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-54-0.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝合金灯体",
  "dimsZh": "Ø48(Ø32)*H55",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-56",
  "page": 56,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2065G",
  "codes": [
   "IGL-2065G-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø65(Ø45)*H68",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "4.5W / 1x6W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-56-0.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝合金灯体",
  "dimsZh": "Ø65(Ø45)*H68",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-58",
  "page": 58,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2080G",
  "codes": [
   "IGL-2080G-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø80(Ø56)*H73",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "7.5W / 1x10W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-58-0.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝合金灯体",
  "dimsZh": "Ø80(Ø56)*H73",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-62",
  "page": 62,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2035R/2050R",
  "codes": [
   "IGL-2035R-CL",
   "IGL-2050R-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø35*H48/Ø50*H51",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "Could Use Underwater",
  "power": "1W / 2W / 1x1W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/inground-62-0.jpg",
   "assets/img/products/inground-62-1.jpg"
  ],
  "materialZh": "S5316 灯体",
  "dimsZh": "Ø35*H48/Ø50*H51",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": "可用于水下"
 },
 {
  "id": "inground-66",
  "page": 66,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2038R/S",
  "codes": [
   "IGL-2038R-CL",
   "IGL-2058S-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø38*H65/W38*H65",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2W / 1x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-66-0.jpg",
   "assets/img/products/inground-66-1.jpg"
  ],
  "materialZh": "S5316 面盖 : 铝灯体",
  "dimsZh": "Ø38*H65/W38*H65",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-68",
  "page": 68,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2045R/S",
  "codes": [
   "IGL-2045R-CL",
   "IGL-2045S-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL Body",
  "dims": "Ø45*H72/W45*H72",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "3W / 1x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-68-0.jpg",
   "assets/img/products/inground-68-1.jpg"
  ],
  "materialZh": "S5316 面盖 : 铝灯体",
  "dimsZh": "Ø45*H72/W45*H72",
  "distZh": "钢化玻璃 , 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-70",
  "page": 70,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2058E/F/E-S",
  "codes": [
   "IGL-2058E-CL",
   "IGL-2058F-CL",
   "IGL-2058E-S"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø58*H55/W58*H55/Ø58*H55",
  "dist": "Tempered Glas, Clea//Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.3W / 1x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-70-0.jpg",
   "assets/img/products/inground-70-1.jpg",
   "assets/img/products/inground-70-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø58*H55/ W58*H55/Ø58*H55",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-72",
  "page": 72,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2058R/S/R-S",
  "codes": [
   "IGL-2058R-CL",
   "IGL-2058S-CL",
   "IGL-2058R-S"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø58*H82/W58*H82/Ø58*H82",
  "dist": "Tempered GIass,Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "2.3W / 5W / 1x5W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-72-0.jpg",
   "assets/img/products/inground-72-1.jpg",
   "assets/img/products/inground-72-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø58*H82/ W58*H82/Ø58*H82",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-74",
  "page": 74,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2116R/R-S",
  "codes": [
   "IGL-2116R-CL",
   "IGL-2116R-S"
  ],
  "ip": "IP67",
  "material": "Stainless Steel Cover; AL. Body",
  "dims": "Ø116*H74/Ø116*H50",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "6W / 1x10W / 12x0.5W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-74-0.jpg",
   "assets/img/products/inground-74-1.jpg"
  ],
  "materialZh": "不锈钢面盖 ; 铝合金灯体",
  "dimsZh": "Ø116*H74/Ø116*H50",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-76",
  "page": 76,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2160R/R-T",
  "codes": [
   "IGL-2160R-CL",
   "IGL-2160R-T"
  ],
  "ip": "IP67",
  "material": "SS316 Cover; AL. Body",
  "dims": "Ø160*H80/Ø160*H80",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "12W / 6W / 6x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-76-0.jpg",
   "assets/img/products/inground-76-1.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø160*H80/Ø160*H80",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-78",
  "page": 78,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2180R",
  "codes": [
   "IGL-2180R-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover; AL. Body",
  "dims": "Ø180*H69",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "24W / 12x3W / 1x25W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-78-0.jpg"
  ],
  "materialZh": "SS316 面盖 : 铝灯体",
  "dimsZh": "Ø180*H69",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "inground-80",
  "page": 80,
  "cat": "inground",
  "catName": "Inground Lights",
  "model": "2250R",
  "codes": [
   "IGL-2250R-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover; AL. Body",
  "dims": "Ø250*H45",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "36W / 18x3W / 1x45W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/inground-80-0.jpg"
  ],
  "materialZh": "SS316 面盖 : 铝灯体",
  "dimsZh": "Ø250*H45",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "spot-84",
  "page": 84,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3047R",
  "codes": [
   "LSP-3047R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body. Black",
  "dims": "Ø47*L93*H71",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "5W / 1x7W / 2.3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-84-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø47*L93*H71",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-86",
  "page": 86,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3063R",
  "codes": [
   "LSP-3063R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body. Black",
  "dims": "Ø63*L120*H71",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "10W / 1x10W / 9W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-86-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø63*L120*H71",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-88",
  "page": 88,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3075R",
  "codes": [
   "LSP-3075R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body. Black",
  "dims": "Ø75*L130*H71",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "15W / 1x20W / 20W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-88-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø73*L130*H71",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-90",
  "page": 90,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3095R",
  "codes": [
   "LSP-3095R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body. Black",
  "dims": "Ø95*L163*H71",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "25W / 1x25W / 24W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-90-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø95*L163*H71",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-92",
  "page": 92,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3115R",
  "codes": [
   "LSP-3115R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body. Black",
  "dims": "Ø114*L193*H71",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "35W / 1x35W / 30W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-92-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø114*L193*H71",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-96",
  "page": 96,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3042R",
  "codes": [
   "IGL-3042R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body, Black",
  "dims": "Ø42*L82*H60",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "3W / 6W / 1x3W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-96-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø42*L82*H60",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-98",
  "page": 98,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3058R",
  "codes": [
   "IGL-3058R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body, Black",
  "dims": "Ø58*L100*H68",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "9W / 1x10W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-98-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø58*L100*H68",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "spot-100",
  "page": 100,
  "cat": "spot",
  "catName": "Spot Lights",
  "model": "3068R",
  "codes": [
   "IGL-3068R-NA"
  ],
  "ip": "IP66",
  "material": "AL. Body, Black",
  "dims": "Ø68*L120*H51",
  "dist": "Tempered Glass, Clear",
  "supply": "Included",
  "accessory": "Spike/Base/Strap/Clamp",
  "remark": "",
  "power": "15W / 1x20W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/spot-100-0.jpg"
  ],
  "materialZh": "铝灯体 , 砂黑",
  "dimsZh": "Ø68*L120*H51",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "内置",
  "accessoryZh": "地插 / 底盘 / 绑树带 / 抱箍",
  "remarkZh": ""
 },
 {
  "id": "underwater-104",
  "page": 104,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4035R/4050R/4062R/4078R",
  "codes": [
   "LUW-4035R-CL",
   "LUW-4050R-CL",
   "LUW-4062R-CL",
   "LUW-4078R-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø35(28)*H48 / Ø50(37)*H51",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "Could Use Underwate",
  "power": "1W / 2W / 3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-104-0.jpg",
   "assets/img/products/underwater-104-1.jpg",
   "assets/img/products/underwater-104-2.jpg"
  ],
  "materialZh": "SS316 灯体",
  "dimsZh": "Ø35(28)*H48 / Ø50(37)*H51",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": "应用于水下"
 },
 {
  "id": "underwater-106",
  "page": 106,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4116R/4160R/4180R/4250R",
  "codes": [
   "LUW-4116R-CL",
   "LUW-4160R-CL",
   "LUW-4180R-CL",
   "LUW-4250R-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø116(Ø103|60)*H55 / Ø160(Ø143|100)*H55",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "8W / 12W / 24W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-106-0.jpg",
   "assets/img/products/underwater-106-1.jpg",
   "assets/img/products/underwater-106-2.jpg"
  ],
  "materialZh": "SS316 灯体",
  "dimsZh": "Ø116(Ø103|60)*H55 / Ø160(Ø143|100)*H55",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "underwater-108",
  "page": 108,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4246L",
  "codes": [
   "LUW-4246L-CL"
  ],
  "ip": "IP68",
  "material": "SS316",
  "dims": "L246*W76*H65",
  "dist": "Tempered Glass, Clear",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "12W / 6x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-108-0.jpg"
  ],
  "materialZh": "SS316",
  "dimsZh": "L246*W76*H65",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "underwater-112",
  "page": 112,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4062F",
  "codes": [
   "LUW-4062F-CL"
  ],
  "ip": "IP68",
  "material": "SS316",
  "dims": "Ø62(Ø40)*H75",
  "dist": "Tempered Glass Clear",
  "supply": "Not Included",
  "accessory": "Bracket",
  "remark": "",
  "power": "3W / 5W / 1x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-112-0.jpg"
  ],
  "materialZh": "SS316",
  "dimsZh": "Ø62(Ø40)*H75",
  "distZh": "钢化玻璃 / 透明",
  "supplyZh": "另配",
  "accessoryZh": "支架",
  "remarkZh": "EN CH"
 },
 {
  "id": "underwater-114",
  "page": 114,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4103F / 4143F / 4163F",
  "codes": [
   "LUW-4103F-CL",
   "LUW-4143F-CL",
   "LUW-4163F-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø103*L55*H70 / Ø143*L55*H93",
  "dist": "Tempered Glass, Clear/Frosted",
  "supply": "Not Included",
  "accessory": "U Bracket",
  "remark": "",
  "power": "12W / 24W / 36W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-114-0.jpg",
   "assets/img/products/underwater-114-1.jpg",
   "assets/img/products/underwater-114-2.jpg"
  ],
  "materialZh": "SS316 灯体",
  "dimsZh": "Ø103*L55*H70 / Ø143*L55*H93",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "U 型支架",
  "remarkZh": ""
 },
 {
  "id": "underwater-116",
  "page": 116,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4115F",
  "codes": [
   "LUW-4115F-CL"
  ],
  "ip": "IP68",
  "material": "S5316 Body",
  "dims": "Ø115*H33/(Ø112+83)",
  "dist": "Tempered Glass, Clear",
  "supply": "Not Included",
  "accessory": "U Bracket(Optional)",
  "remark": "",
  "power": "12W / 6x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-116-0.jpg"
  ],
  "materialZh": "S5316 灯体",
  "dimsZh": "Ø115*H33/(Ø112+83)",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "另配",
  "accessoryZh": "U 型支架 ( 可选 )",
  "remarkZh": ""
 },
 {
  "id": "underwater-118",
  "page": 118,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4092F/4132F/4152F",
  "codes": [
   "LUW-4092F-CL",
   "LUW-4132F-CL",
   "LUW-4152F-CL"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø92*L38*H110/(W130*H50)",
  "dist": "Tempered Glass, Clear",
  "supply": "Not Included",
  "accessory": ": Tripod(Optional)",
  "remark": "",
  "power": "6W / 12W / 24W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-118-0.jpg",
   "assets/img/products/underwater-118-1.jpg",
   "assets/img/products/underwater-118-2.jpg"
  ],
  "materialZh": "SS316 灯体",
  "dimsZh": "Ø92*L38*H110/(W130*H50)",
  "distZh": "钢化玻璃 透明",
  "supplyZh": "另配",
  "accessoryZh": "三脚架 ( 可选 )",
  "remarkZh": ""
 },
 {
  "id": "underwater-120",
  "page": 120,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4211F",
  "codes": [
   "LUW-4211F-CL"
  ],
  "ip": "IP68",
  "material": "S5316 Body",
  "dims": "L210*W77*H60",
  "dist": "Tempered Glass, Clear",
  "supply": "Not Included",
  "accessory": "Bracket",
  "remark": "",
  "power": "12W / 6x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-120-0.jpg"
  ],
  "materialZh": "S5316 灯体",
  "dimsZh": "L210*W77*H60",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "另配",
  "accessoryZh": "支架",
  "remarkZh": ""
 },
 {
  "id": "underwater-122",
  "page": 122,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4070W",
  "codes": [
   "LUW-4070W-10",
   "LUW-4070W-05"
  ],
  "ip": "IP68",
  "material": "SS316",
  "dims": "L=1m W76*H65",
  "dist": "Tempeered Glass, Clear",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "48W / 24x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-122-0.jpg",
   "assets/img/products/underwater-122-1.jpg",
   "assets/img/products/underwater-122-2.jpg"
  ],
  "materialZh": "SS316",
  "dimsZh": "L=1m W76*H65",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "underwater-126",
  "page": 126,
  "cat": "underwater",
  "catName": "Underwater Lights",
  "model": "4150F/4160F/4182F",
  "codes": [
   "LUW-4150F",
   "LUW-4160F",
   "LUW-4182F"
  ],
  "ip": "IP68",
  "material": "SS316 Body",
  "dims": "Ø150*H37/Ø160*H38/Ø182*H38",
  "dist": "Tempered Glas Clea",
  "supply": "Not Included",
  "accessory": "Junction Pipe/Sleeve(Optional)",
  "remark": "",
  "power": "18W / 24W / 9x3W",
  "voltage": "DC24V",
  "images": [
   "assets/img/products/underwater-126-0.jpg",
   "assets/img/products/underwater-126-1.jpg",
   "assets/img/products/underwater-126-2.jpg"
  ],
  "materialZh": "SS316 灯体",
  "dimsZh": "Ø150*H37/ Ø160*H38/Ø182*H38",
  "distZh": "钢化玻璃 , 透明",
  "supplyZh": "另配",
  "accessoryZh": "接合管 / 套管（可选）",
  "remarkZh": "EN CH"
 },
 {
  "id": "linear-130",
  "page": 130,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5046W",
  "codes": [
   "LIG-5046W-CL",
   "LIG-5046W-FR"
  ],
  "ip": "IP67",
  "material": "Tempered Glass Cover; AL. Body",
  "dims": "W46*H54 L=1m(0.5m/0.3m)",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-130-0.jpg",
   "assets/img/products/linear-130-1.jpg",
   "assets/img/products/linear-130-2.jpg"
  ],
  "materialZh": "钢化玻璃面 : 铝灯体",
  "dimsZh": "W46*H45 L=1m(0.5m/0.3m)",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "linear-132",
  "page": 132,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5058W",
  "codes": [
   "LIG-5058W-CL",
   "LIG-5058W-FR"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W58*H54 L=1m(0.5m/0.3m)+28mm",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-132-0.jpg",
   "assets/img/products/linear-132-1.jpg",
   "assets/img/products/linear-132-2.jpg"
  ],
  "materialZh": "SS316 面盖 , 铝灯体",
  "dimsZh": "W58*H54 L=1m(0.5m/0.3m)+28mm",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "linear-134",
  "page": 134,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5055W",
  "codes": [
   "LIG-5055W-CL",
   "LIG-5055W-FR"
  ],
  "ip": "IP67",
  "material": "Tempered Glass Cover; AL. Body",
  "dims": "W55*H65 L=1m(0.5m/0.3m)",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-134-0.jpg",
   "assets/img/products/linear-134-1.jpg",
   "assets/img/products/linear-134-2.jpg"
  ],
  "materialZh": "钢化玻璃面 : 铝灯体",
  "dimsZh": "W55*H65 L=1m(0.5m/0.3m)",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "linear-136",
  "page": 136,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5069W",
  "codes": [
   "LIG-5069W-CL",
   "LIG-5069W-FR"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W69*H68 L=1m(0.5m/0.3m)+28mm",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-136-0.jpg",
   "assets/img/products/linear-136-1.jpg",
   "assets/img/products/linear-136-2.jpg"
  ],
  "materialZh": "SS316 面盖 , 铝灯体",
  "dimsZh": "W69*H68 L=1m(0.5m/0.3m)+28mm",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "linear-138",
  "page": 138,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5075W",
  "codes": [
   "LIG-5075W-CL",
   "LIG-5075W-FR"
  ],
  "ip": "IP67",
  "material": "Tempered Glass Cover; AL. Body",
  "dims": "W75*H78 L=1m(0.5m/0.3m)",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-138-0.jpg",
   "assets/img/products/linear-138-1.jpg",
   "assets/img/products/linear-138-2.jpg"
  ],
  "materialZh": "钢化玻璃面 : 铝灯体",
  "dimsZh": "W75*H78 L=1m(0.5m/0.3m)",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "linear-140",
  "page": 140,
  "cat": "linear",
  "catName": "Linear Lights",
  "model": "5090W",
  "codes": [
   "LIG-5090W-CL",
   "LIG-5090W-FR"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W69*H68 L=1m(0.5m/0.3m)+28mm",
  "dist": ": Tempered Glass, Clea/Frosted",
  "supply": "Not Included",
  "accessory": "Pre-buired Sleeve",
  "remark": "",
  "power": "18W / 24W / 36W",
  "voltage": "AC 220-240V / DC24V",
  "images": [
   "assets/img/products/linear-140-0.jpg",
   "assets/img/products/linear-140-1.jpg",
   "assets/img/products/linear-140-2.jpg"
  ],
  "materialZh": "SS316 面盖 , 铝灯体",
  "dimsZh": "W69*H68 L=1m(0.5m/0.3m)+28mm",
  "distZh": "钢化玻璃，透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "预埋件",
  "remarkZh": ""
 },
 {
  "id": "downlight-144",
  "page": 144,
  "cat": "downlight",
  "catName": "Downlights",
  "model": "6135R/6185R/6215R",
  "codes": [
   "IGL-6135R-CL",
   "IGL-6185R-CL",
   "IGL-6215R-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø135*H126(Cutout Ø120)",
  "dist": "Tempered Glas Clea/Frosted",
  "supply": "Not Included",
  "accessory": "",
  "remark": "",
  "power": "9W / 21W / 36W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/downlight-144-0.jpg",
   "assets/img/products/downlight-144-1.jpg",
   "assets/img/products/downlight-144-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø135*H126( 开孔Ø120）",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "另配",
  "accessoryZh": "",
  "remarkZh": ""
 },
 {
  "id": "downlight-146",
  "page": 146,
  "cat": "downlight",
  "catName": "Downlights",
  "model": "6135R/6185R/6215R-T",
  "codes": [
   "IGL-6135R-T",
   "IGL-6185R-T",
   "IGL-6215R-T"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "Ø135*H126(Cutout Ø120)",
  "dist": "Tempered GIass,Clear",
  "supply": "Included",
  "accessory": "",
  "remark": "",
  "power": "6W / 14W / 15W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/downlight-146-0.jpg",
   "assets/img/products/downlight-146-1.jpg",
   "assets/img/products/downlight-146-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "Ø135*H126( 开孔Ø120）",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "",
  "remarkZh": ""
 },
 {
  "id": "downlight-148",
  "page": 148,
  "cat": "downlight",
  "catName": "Downlights",
  "model": "6135S/6185S/6215S",
  "codes": [
   "IGL-6135S-CL",
   "IGL-6185S-CL",
   "IGL-6215S-CL"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL. Body",
  "dims": "W135*H126(CutoutW120)",
  "dist": "Tempered Glas Clea/fioste",
  "supply": "Included",
  "accessory": "",
  "remark": "",
  "power": "12W / 27W / 36W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/downlight-148-0.jpg",
   "assets/img/products/downlight-148-1.jpg",
   "assets/img/products/downlight-148-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "W135*H126( 开孔 W120）",
  "distZh": "钢化玻璃 透明 / 磨砂",
  "supplyZh": "内置",
  "accessoryZh": "",
  "remarkZh": ""
 },
 {
  "id": "downlight-150",
  "page": 150,
  "cat": "downlight",
  "catName": "Downlights",
  "model": "6135S/6185S/6215S-T",
  "codes": [
   "IGL-6135S-T",
   "IGL-6185S-T",
   "IGL-6215S-T"
  ],
  "ip": "IP67",
  "material": "SS316 Cover AL Body",
  "dims": "W135*H126(CutoutW120)",
  "dist": "Tempered GIass,Clear",
  "supply": "Included",
  "accessory": "",
  "remark": "",
  "power": "8W / 26W / 9W",
  "voltage": "AC 220-240V / DC24V / AC 220V",
  "images": [
   "assets/img/products/downlight-150-0.jpg",
   "assets/img/products/downlight-150-1.jpg",
   "assets/img/products/downlight-150-2.jpg"
  ],
  "materialZh": "SS316 面盖 ; 铝灯体",
  "dimsZh": "W135*H126( 开孔 W120）",
  "distZh": "钢化玻璃，透明",
  "supplyZh": "内置",
  "accessoryZh": "",
  "remarkZh": ""
 }
];
